import { createFileRoute } from "@tanstack/react-router";
import { lazy, Suspense, useEffect, useState } from "react";
import { BootScreen } from "@/components/helios/boot-screen";

const HeliosApp = lazy(() => import("@/components/helios/helios-app"));

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  if (!mounted) return <BootScreen />;

  return (
    <Suspense fallback={<BootScreen />}>
      <HeliosApp />
    </Suspense>
  );
}
