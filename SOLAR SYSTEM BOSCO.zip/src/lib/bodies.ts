export type BodyKind = "star" | "planet" | "dwarf" | "moon";

export type BodyFact = {
  label: string;
  value: string;
};

export type RingSpec = {
  inner: number;
  outer: number;
  kind: "saturn" | "uranus";
};

export type CelestialBody = {
  id: string;
  name: string;
  parentId: string | null;
  kind: BodyKind;
  /** Visual sphere radius in scene units. */
  radius: number;
  /** Mean distance from parent in scene units. */
  orbit: number;
  eccentricity: number;
  /** Sidereal orbit period in Earth years. */
  period: number;
  /** Visual spin period in Earth years (negative = retrograde). */
  spinPeriod: number;
  /** Axial tilt in degrees. */
  tilt: number;
  /** Orbital inclination in degrees. */
  inclination: number;
  /** Longitude of ascending node in degrees. */
  lan: number;
  /** Starting true-anomaly offset in radians. */
  phase: number;
  color: string;
  atmosphere?: string;
  rings?: RingSpec;
  clouds?: boolean;
  description: string;
  facts: BodyFact[];
};

export const SECONDS_PER_YEAR = 22;

export const BODIES: CelestialBody[] = [
  {
    id: "sun",
    name: "Sun",
    parentId: null,
    kind: "star",
    radius: 2.65,
    orbit: 0,
    eccentricity: 0,
    period: 1,
    spinPeriod: 0.9,
    tilt: 7.25,
    inclination: 0,
    lan: 0,
    phase: 0,
    color: "#ffcc66",
    description:
      "A G2V yellow dwarf holding the system together. Nearly all of the solar system's mass lives here, pouring light and wind across every orbit.",
    facts: [
      { label: "Type", value: "G2V star" },
      { label: "Diameter", value: "1.39 million km" },
      { label: "Surface", value: "5,500 °C" },
      { label: "Age", value: "4.6 billion yr" },
    ],
  },
  {
    id: "mercury",
    name: "Mercury",
    parentId: "sun",
    kind: "planet",
    radius: 0.17,
    orbit: 5.15,
    eccentricity: 0.12,
    period: 0.241,
    spinPeriod: 0.16,
    tilt: 0.03,
    inclination: 7,
    lan: 48,
    phase: 1.2,
    color: "#9a9388",
    description:
      "The innermost world: a cratered, iron-rich messenger with no real atmosphere. Days last longer than years, and the sky never holds a cloud.",
    facts: [
      { label: "Class", value: "Terrestrial" },
      { label: "Distance", value: "0.39 AU" },
      { label: "Year", value: "88 days" },
      { label: "Moons", value: "None" },
    ],
  },
  {
    id: "venus",
    name: "Venus",
    parentId: "sun",
    kind: "planet",
    radius: 0.28,
    orbit: 6.85,
    eccentricity: 0.04,
    period: 0.615,
    spinPeriod: -0.55,
    tilt: 177.4,
    inclination: 3.4,
    lan: 76,
    phase: 4.1,
    color: "#d9c19a",
    atmosphere: "#e8d4a8",
    description:
      "Earth's veiled twin, spinning backward under a crushing carbon-dioxide sky. The surface is hotter than Mercury, lit by a jaundiced overcast.",
    facts: [
      { label: "Class", value: "Terrestrial" },
      { label: "Distance", value: "0.72 AU" },
      { label: "Year", value: "225 days" },
      { label: "Day", value: "243 days, retrograde" },
    ],
  },
  {
    id: "earth",
    name: "Earth",
    parentId: "sun",
    kind: "planet",
    radius: 0.3,
    orbit: 8.55,
    eccentricity: 0.017,
    period: 1,
    spinPeriod: 0.07,
    tilt: 23.4,
    inclination: 0,
    lan: 0,
    phase: 0.35,
    color: "#3d7cc4",
    atmosphere: "#7eb7ff",
    clouds: true,
    description:
      "The living world. Liquid oceans, a shielding magnetic field, and one large moon keep the climate within the narrow band that lets us look back out.",
    facts: [
      { label: "Class", value: "Terrestrial" },
      { label: "Distance", value: "1.00 AU" },
      { label: "Year", value: "365.25 days" },
      { label: "Moons", value: "1" },
    ],
  },
  {
    id: "moon",
    name: "Moon",
    parentId: "earth",
    kind: "moon",
    radius: 0.082,
    orbit: 0.78,
    eccentricity: 0.055,
    period: 0.0748,
    spinPeriod: 0.0748,
    tilt: 6.7,
    inclination: 5.1,
    lan: 125,
    phase: 2.4,
    color: "#c9c3b6",
    description:
      "Earth's companion, tidally locked so the same face always turns toward home. Its pull stirs the oceans and steadies our axial tilt.",
    facts: [
      { label: "Class", value: "Rocky moon" },
      { label: "Distance", value: "384,400 km" },
      { label: "Period", value: "27.3 days" },
      { label: "Origin", value: "Giant impact" },
    ],
  },
  {
    id: "mars",
    name: "Mars",
    parentId: "sun",
    kind: "planet",
    radius: 0.2,
    orbit: 10.55,
    eccentricity: 0.09,
    period: 1.881,
    spinPeriod: 0.075,
    tilt: 25.2,
    inclination: 1.85,
    lan: 49,
    phase: 5.6,
    color: "#c07a54",
    atmosphere: "#d4a078",
    description:
      "A cold desert of rusted dust and ancient riverbeds. Ice caps still breathe with the seasons, and the tallest volcano in the system stands silent.",
    facts: [
      { label: "Class", value: "Terrestrial" },
      { label: "Distance", value: "1.52 AU" },
      { label: "Year", value: "687 days" },
      { label: "Moons", value: "2 (Phobos, Deimos)" },
    ],
  },
  {
    id: "jupiter",
    name: "Jupiter",
    parentId: "sun",
    kind: "planet",
    radius: 0.98,
    orbit: 16.4,
    eccentricity: 0.048,
    period: 11.86,
    spinPeriod: 0.032,
    tilt: 3.1,
    inclination: 1.3,
    lan: 100,
    phase: 2.8,
    color: "#c4a07a",
    atmosphere: "#e0c49a",
    description:
      "A failed star of hydrogen and helium, wrapping a family of worlds in radiation and storms. The Great Red Spot has raged for centuries.",
    facts: [
      { label: "Class", value: "Gas giant" },
      { label: "Distance", value: "5.20 AU" },
      { label: "Year", value: "11.9 years" },
      { label: "Moons", value: "95+" },
    ],
  },
  {
    id: "io",
    name: "Io",
    parentId: "jupiter",
    kind: "moon",
    radius: 0.07,
    orbit: 1.45,
    eccentricity: 0.004,
    period: 0.0048,
    spinPeriod: 0.0048,
    tilt: 0,
    inclination: 0.05,
    lan: 0,
    phase: 0.4,
    color: "#e6d16a",
    description:
      "The most volcanic body we know. Jupiter's tides knead Io's interior until sulfur plumes fountain hundreds of kilometres into space.",
    facts: [
      { label: "Class", value: "Galilean moon" },
      { label: "Period", value: "1.8 days" },
      { label: "Feature", value: "Active volcanoes" },
      { label: "Discovered", value: "1610" },
    ],
  },
  {
    id: "europa",
    name: "Europa",
    parentId: "jupiter",
    kind: "moon",
    radius: 0.064,
    orbit: 1.85,
    eccentricity: 0.009,
    period: 0.0097,
    spinPeriod: 0.0097,
    tilt: 0.1,
    inclination: 0.47,
    lan: 20,
    phase: 1.7,
    color: "#c9d4de",
    description:
      "An ice shell over a global ocean. Fractures score the surface like a frozen sea, and that hidden water is one of the best hopes for life nearby.",
    facts: [
      { label: "Class", value: "Galilean moon" },
      { label: "Period", value: "3.5 days" },
      { label: "Feature", value: "Subsurface ocean" },
      { label: "Discovered", value: "1610" },
    ],
  },
  {
    id: "ganymede",
    name: "Ganymede",
    parentId: "jupiter",
    kind: "moon",
    radius: 0.09,
    orbit: 2.32,
    eccentricity: 0.001,
    period: 0.0196,
    spinPeriod: 0.0196,
    tilt: 0.2,
    inclination: 0.2,
    lan: 40,
    phase: 3.3,
    color: "#9aa0a8",
    description:
      "The largest moon in the solar system — bigger than Mercury — and the only one with its own magnetic field, wrapped in grooved ice and dark terrain.",
    facts: [
      { label: "Class", value: "Galilean moon" },
      { label: "Period", value: "7.2 days" },
      { label: "Feature", value: "Own magnetosphere" },
      { label: "Discovered", value: "1610" },
    ],
  },
  {
    id: "callisto",
    name: "Callisto",
    parentId: "jupiter",
    kind: "moon",
    radius: 0.082,
    orbit: 2.92,
    eccentricity: 0.007,
    period: 0.0457,
    spinPeriod: 0.0457,
    tilt: 0,
    inclination: 0.5,
    lan: 80,
    phase: 5.1,
    color: "#6f6860",
    description:
      "An ancient, cratered ice world at the edge of Jupiter's radiation. It has barely changed since the late heavy bombardment.",
    facts: [
      { label: "Class", value: "Galilean moon" },
      { label: "Period", value: "16.7 days" },
      { label: "Feature", value: "Oldest surface" },
      { label: "Discovered", value: "1610" },
    ],
  },
  {
    id: "saturn",
    name: "Saturn",
    parentId: "sun",
    kind: "planet",
    radius: 0.82,
    orbit: 21.6,
    eccentricity: 0.054,
    period: 29.46,
    spinPeriod: 0.036,
    tilt: 26.7,
    inclination: 2.5,
    lan: 113,
    phase: 0.9,
    color: "#e0c48a",
    atmosphere: "#ead8a8",
    rings: { inner: 1.15, outer: 2.45, kind: "saturn" },
    description:
      "Pale gold and almost light enough to float on water. Its rings are ice and dust, a razor-thin architecture visible across the outer system.",
    facts: [
      { label: "Class", value: "Gas giant" },
      { label: "Distance", value: "9.58 AU" },
      { label: "Year", value: "29.5 years" },
      { label: "Rings", value: "Ice, kilometres thin" },
    ],
  },
  {
    id: "titan",
    name: "Titan",
    parentId: "saturn",
    kind: "moon",
    radius: 0.088,
    orbit: 2.55,
    eccentricity: 0.029,
    period: 0.0437,
    spinPeriod: 0.0437,
    tilt: 0,
    inclination: 0.3,
    lan: 15,
    phase: 1.1,
    color: "#c4a06a",
    atmosphere: "#d4b07a",
    description:
      "A moon with weather. Methane rivers cut through organic haze toward hydrocarbon seas — the only other surface liquid we have walked beside, by proxy.",
    facts: [
      { label: "Class", value: "Icy moon" },
      { label: "Period", value: "16 days" },
      { label: "Feature", value: "Methane lakes" },
      { label: "Atmosphere", value: "Dense N₂ haze" },
    ],
  },
  {
    id: "uranus",
    name: "Uranus",
    parentId: "sun",
    kind: "planet",
    radius: 0.48,
    orbit: 26.2,
    eccentricity: 0.047,
    period: 84.0,
    spinPeriod: 0.05,
    tilt: 97.8,
    inclination: 0.77,
    lan: 74,
    phase: 3.7,
    color: "#9ad0d4",
    atmosphere: "#b7e0e2",
    rings: { inner: 1.2, outer: 1.85, kind: "uranus" },
    description:
      "An ice giant rolled onto its side, so its poles take turns facing the Sun for decades. Pale methane air gives it that quiet sea-glass colour.",
    facts: [
      { label: "Class", value: "Ice giant" },
      { label: "Distance", value: "19.2 AU" },
      { label: "Year", value: "84 years" },
      { label: "Tilt", value: "98°" },
    ],
  },
  {
    id: "neptune",
    name: "Neptune",
    parentId: "sun",
    kind: "planet",
    radius: 0.46,
    orbit: 30.6,
    eccentricity: 0.009,
    period: 164.8,
    spinPeriod: 0.046,
    tilt: 28.3,
    inclination: 1.77,
    lan: 131,
    phase: 5.9,
    color: "#3a6fd4",
    atmosphere: "#5b8eec",
    description:
      "The last giant, found with mathematics before a telescope. Dark storms and the fastest winds in the system streak a deep, cobalt hydrogen sea.",
    facts: [
      { label: "Class", value: "Ice giant" },
      { label: "Distance", value: "30.1 AU" },
      { label: "Year", value: "165 years" },
      { label: "Winds", value: "Up to 2,000 km/h" },
    ],
  },
  {
    id: "pluto",
    name: "Pluto",
    parentId: "sun",
    kind: "dwarf",
    radius: 0.12,
    orbit: 34.8,
    eccentricity: 0.22,
    period: 248,
    spinPeriod: 0.017,
    tilt: 122.5,
    inclination: 17.2,
    lan: 110,
    phase: 0.2,
    color: "#c4b09a",
    description:
      "A heart-marked world of nitrogen ice at the edge of the Kuiper belt. Its orbit weaves inside Neptune's for part of each long century.",
    facts: [
      { label: "Class", value: "Dwarf planet" },
      { label: "Distance", value: "39.5 AU avg." },
      { label: "Year", value: "248 years" },
      { label: "Companion", value: "Charon" },
    ],
  },
];

export const BODY_BY_ID: Record<string, CelestialBody> = Object.fromEntries(
  BODIES.map((body) => [body.id, body]),
);

export const PICKER_BODIES = BODIES.filter((body) => body.parentId === "sun" || body.id === "sun");

export function childrenOf(id: string): CelestialBody[] {
  return BODIES.filter((body) => body.parentId === id);
}

export function focusDistance(id: string): number {
  if (id === "system") return 42;
  const body = BODY_BY_ID[id];
  if (!body) return 36;
  const ring = body.rings?.outer ?? 1;
  const extent = Math.max(body.radius, body.radius * ring);
  if (body.kind === "star") return extent * 5.2;
  if (body.kind === "moon") return Math.max(extent * 12, 1.2);
  if (body.id === "saturn") return 7.6;
  if (body.id === "jupiter") return 6.4;
  if (body.id === "uranus" || body.id === "neptune") return 3.8;
  return Math.max(extent * 11.5, 3.4);
}

export function keplerRadius(semiMajor: number, eccentricity: number, theta: number): number {
  const e = eccentricity;
  return (semiMajor * (1 - e * e)) / (1 + e * Math.cos(theta));
}

export function makeOrbitPoints(
  orbit: number,
  eccentricity: number,
  segments = 160,
): [number, number, number][] {
  const pts: [number, number, number][] = [];
  for (let i = 0; i <= segments; i++) {
    const theta = (i / segments) * Math.PI * 2;
    const r = keplerRadius(orbit, eccentricity, theta);
    pts.push([Math.cos(theta) * r, 0, Math.sin(theta) * r]);
  }
  return pts;
}
