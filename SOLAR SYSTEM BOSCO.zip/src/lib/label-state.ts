export type ScreenLabel = {
  id: string;
  name: string;
  x: number;
  y: number;
  visible: boolean;
};

export const screenLabels: ScreenLabel[] = [];
