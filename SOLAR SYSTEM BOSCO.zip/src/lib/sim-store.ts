import { create } from "zustand";
import { persist } from "zustand/middleware";

export type SimState = {
  paused: boolean;
  timeScale: number;
  showLabels: boolean;
  showOrbits: boolean;
  focusedId: string;
  selectedId: string | null;
  togglePaused: () => void;
  setPaused: (paused: boolean) => void;
  setTimeScale: (timeScale: number) => void;
  setShowLabels: (showLabels: boolean) => void;
  setShowOrbits: (showOrbits: boolean) => void;
  focus: (id: string) => void;
  resetView: () => void;
};

export const useSim = create<SimState>()(
  persist(
    (set) => ({
      paused: false,
      timeScale: 1,
      showLabels: true,
      showOrbits: true,
      focusedId: "system",
      selectedId: null,
      togglePaused: () => set((s) => ({ paused: !s.paused })),
      setPaused: (paused) => set({ paused }),
      setTimeScale: (timeScale) => set({ timeScale }),
      setShowLabels: (showLabels) => set({ showLabels }),
      setShowOrbits: (showOrbits) => set({ showOrbits }),
      focus: (id) =>
        set({
          focusedId: id,
          selectedId: id === "system" ? null : id,
        }),
      resetView: () => set({ focusedId: "system", selectedId: null }),
    }),
    {
      name: "helios-observatory",
      partialize: (s) => ({
        timeScale: s.timeScale,
        showLabels: s.showLabels,
        showOrbits: s.showOrbits,
      }),
    },
  ),
);

export const simClock = {
  years: 0,
};

export function formatTimeScale(scale: number): string {
  if (scale < 10) return `${scale.toFixed(1).replace(/\.0$/, "")}×`;
  return `${Math.round(scale)}×`;
}

export function sliderToScale(t: number): number {
  const logMin = Math.log2(0.25);
  const logMax = Math.log2(48);
  return 2 ** (logMin + t * (logMax - logMin));
}

export function scaleToSlider(scale: number): number {
  const logMin = Math.log2(0.25);
  const logMax = Math.log2(48);
  const s = Math.min(48, Math.max(0.25, scale));
  return (Math.log2(s) - logMin) / (logMax - logMin);
}
