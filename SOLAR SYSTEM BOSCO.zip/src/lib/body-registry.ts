import type { Object3D } from "three";

const bodies = new Map<string, Object3D>();

export function registerBody(id: string, object: Object3D | null) {
  if (object) bodies.set(id, object);
  else bodies.delete(id);
}

export function getBody(id: string): Object3D | undefined {
  return bodies.get(id);
}
