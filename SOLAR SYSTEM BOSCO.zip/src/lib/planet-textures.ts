import * as THREE from "three";

function hash(x: number, y: number): number {
  const s = Math.sin(x * 127.1 + y * 311.7) * 43758.5453;
  return s - Math.floor(s);
}

function noise(x: number, y: number): number {
  const ix = Math.floor(x);
  const iy = Math.floor(y);
  const fx = x - ix;
  const fy = y - iy;
  const ux = fx * fx * (3 - 2 * fx);
  const uy = fy * fy * (3 - 2 * fy);
  return (
    (1 - ux) * ((1 - uy) * hash(ix, iy) + uy * hash(ix, iy + 1)) +
    ux * ((1 - uy) * hash(ix + 1, iy) + uy * hash(ix + 1, iy + 1))
  );
}

function fbm(x: number, y: number, octaves = 5): number {
  let v = 0;
  let a = 0.5;
  let f = 1;
  for (let i = 0; i < octaves; i++) {
    v += a * noise(x * f, y * f);
    a *= 0.5;
    f *= 2;
  }
  return v;
}

function mix(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}

function clamp01(v: number): number {
  return Math.min(1, Math.max(0, v));
}

function setRgb(
  data: Uint8ClampedArray,
  i: number,
  r: number,
  g: number,
  b: number,
  a = 255,
) {
  data[i] = r;
  data[i + 1] = g;
  data[i + 2] = b;
  data[i + 3] = a;
}

function makeCanvas(size: number): {
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  img: ImageData;
} {
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) throw new Error("2D context unavailable");
  const img = ctx.createImageData(size, size);
  return { canvas, ctx, img };
}

function toTexture(canvas: HTMLCanvasElement): THREE.CanvasTexture {
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.ClampToEdgeWrapping;
  tex.needsUpdate = true;
  return tex;
}

function paintMercury(data: Uint8ClampedArray, size: number) {
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const u = x / size;
      const v = y / size;
      const n = fbm(u * 8, v * 5, 4);
      const c = 118 + n * 55;
      const i = (y * size + x) * 4;
      setRgb(data, i, c, c - 6, c - 14);
    }
  }
  for (let k = 0; k < 48; k++) {
    const cx = hash(k, 3.2) * size;
    const cy = hash(k, 8.7) * size;
    const r = 2 + hash(k, 1.4) * 16;
    const dark = 0.55 + hash(k, 9.1) * 0.25;
    const r2 = r * r;
    const x0 = Math.max(0, Math.floor(cx - r));
    const x1 = Math.min(size - 1, Math.ceil(cx + r));
    const y0 = Math.max(0, Math.floor(cy - r));
    const y1 = Math.min(size - 1, Math.ceil(cy + r));
    for (let y = y0; y <= y1; y++) {
      for (let x = x0; x <= x1; x++) {
        const dx = x - cx;
        const dy = y - cy;
        const d = dx * dx + dy * dy;
        if (d > r2) continue;
        const t = Math.sqrt(d) / r;
        const i = (y * size + x) * 4;
        const m = mix(dark, 1, t * t);
        data[i] *= m;
        data[i + 1] *= m;
        data[i + 2] *= m;
      }
    }
  }
}

function paintVenus(data: Uint8ClampedArray, size: number) {
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const u = x / size;
      const v = y / size;
      const n = fbm(u * 6 + v * 2, v * 4, 4);
      const streak = Math.sin(v * 14 + n * 4) * 0.5 + 0.5;
      const r = 210 + n * 25 + streak * 12;
      const g = 175 + n * 18;
      const b = 120 + n * 10;
      setRgb(data, (y * size + x) * 4, r, g, b);
    }
  }
}

function paintEarth(data: Uint8ClampedArray, size: number) {
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const u = x / size;
      const v = y / size;
      const lat = v * 2 - 1;
      const n = fbm(u * 7, v * 4, 5);
      const land = n > 0.52 + Math.abs(lat) * 0.04;
      const ice = Math.abs(lat) > 0.82 || (Math.abs(lat) > 0.7 && n > 0.55);
      const i = (y * size + x) * 4;
      if (ice) {
        setRgb(data, i, 230, 236, 242);
      } else if (land) {
        const desert = n > 0.62 && Math.abs(lat) < 0.35;
        if (desert) setRgb(data, i, 168, 148, 88);
        else setRgb(data, i, 46 + n * 30, 108 + n * 20, 58);
      } else {
        const deep = 0.35 + n * 0.25;
        setRgb(data, i, 18 + deep * 20, 52 + deep * 40, 118 + deep * 50);
      }
    }
  }
}

function paintMars(data: Uint8ClampedArray, size: number) {
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const u = x / size;
      const v = y / size;
      const lat = v * 2 - 1;
      const n = fbm(u * 7, v * 5, 5);
      const i = (y * size + x) * 4;
      if (Math.abs(lat) > 0.86) {
        setRgb(data, i, 232, 228, 220);
      } else {
        const r = 168 + n * 50;
        const g = 78 + n * 28;
        const b = 48 + n * 16;
        setRgb(data, i, r, g, b);
      }
    }
  }
}

function paintBands(
  data: Uint8ClampedArray,
  size: number,
  palette: [number, number, number][],
  spot?: { y: number; x: number; r: number; color: [number, number, number] },
) {
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const u = x / size;
      const v = y / size;
      const n = fbm(u * 4, v * 10, 4);
      const band = clamp01(v + (n - 0.5) * 0.08);
      const idx = Math.min(palette.length - 1, Math.floor(band * palette.length));
      const [pr, pg, pb] = palette[idx]!;
      const wobble = (n - 0.5) * 18;
      setRgb(data, (y * size + x) * 4, pr + wobble, pg + wobble * 0.6, pb);
    }
  }
  if (spot) {
    const r2 = spot.r * spot.r;
    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        const dx = (x - spot.x * size) / size;
        const dy = (y - spot.y * size) / (size * 0.55);
        const d = dx * dx * 2.4 + dy * dy;
        if (d > r2) continue;
        const t = 1 - d / r2;
        const i = (y * size + x) * 4;
        data[i] = mix(data[i]!, spot.color[0], t);
        data[i + 1] = mix(data[i + 1]!, spot.color[1], t);
        data[i + 2] = mix(data[i + 2]!, spot.color[2], t);
      }
    }
  }
}

function paintIce(data: Uint8ClampedArray, size: number, base: [number, number, number]) {
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const u = x / size;
      const v = y / size;
      const n = fbm(u * 5, v * 8, 4);
      const i = (y * size + x) * 4;
      setRgb(data, i, base[0] + n * 28, base[1] + n * 22, base[2] + n * 18);
    }
  }
}

function paintMoon(data: Uint8ClampedArray, size: number, base: [number, number, number]) {
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const u = x / size;
      const v = y / size;
      const n = fbm(u * 9, v * 6, 4);
      const i = (y * size + x) * 4;
      setRgb(data, i, base[0] + n * 40, base[1] + n * 38, base[2] + n * 32);
    }
  }
}

export function createBodyTexture(id: string, size = 256): THREE.CanvasTexture {
  const { canvas, ctx, img } = makeCanvas(size);
  const data = img.data;
  switch (id) {
    case "mercury":
    case "callisto":
      paintMercury(data, size);
      break;
    case "venus":
    case "titan":
      paintVenus(data, size);
      break;
    case "earth":
      paintEarth(data, size);
      break;
    case "mars":
      paintMars(data, size);
      break;
    case "jupiter":
      paintBands(
        data,
        size,
        [
          [210, 176, 128],
          [186, 142, 96],
          [228, 204, 164],
          [168, 122, 78],
          [214, 182, 136],
          [152, 108, 72],
        ],
        { x: 0.62, y: 0.58, r: 0.045, color: [176, 72, 48] },
      );
      break;
    case "saturn":
      paintBands(data, size, [
        [232, 210, 150],
        [214, 186, 122],
        [236, 220, 176],
        [198, 168, 108],
        [220, 198, 148],
      ]);
      break;
    case "uranus":
      paintIce(data, size, [140, 196, 200]);
      break;
    case "neptune":
      paintIce(data, size, [42, 92, 196]);
      break;
    case "pluto":
      paintMars(data, size);
      break;
    case "moon":
      paintMoon(data, size, [168, 162, 150]);
      break;
    case "io":
      paintMoon(data, size, [210, 186, 72]);
      break;
    case "europa":
      paintIce(data, size, [186, 198, 210]);
      break;
    case "ganymede":
      paintMoon(data, size, [132, 128, 120]);
      break;
    default:
      paintMoon(data, size, [160, 160, 160]);
  }
  ctx.putImageData(img, 0, 0);
  return toTexture(canvas);
}

export function createCloudTexture(size = 256): THREE.CanvasTexture {
  const { canvas, ctx, img } = makeCanvas(size);
  const data = img.data;
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const u = x / size;
      const v = y / size;
      const n = fbm(u * 8, v * 5, 5);
      const a = n > 0.58 ? (n - 0.58) * 420 : 0;
      setRgb(data, (y * size + x) * 4, 245, 248, 252, clamp01(a / 255) * 255);
    }
  }
  ctx.putImageData(img, 0, 0);
  const tex = toTexture(canvas);
  return tex;
}

export function createRingTexture(kind: "saturn" | "uranus"): THREE.CanvasTexture {
  const w = 1024;
  const h = 64;
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("2D context unavailable");
  for (let x = 0; x < w; x++) {
    const t = x / w;
    let alpha = 0;
    if (kind === "saturn") {
      if (t < 0.08) alpha = 0;
      else if (t > 0.44 && t < 0.5) alpha = 0.03;
      else alpha = 0.42 + Math.sin(t * 90) * 0.16 + Math.sin(t * 17) * 0.08;
      alpha *= 0.92;
      const c = 210 + Math.sin(t * 40) * 18;
      ctx.fillStyle = `rgba(${c},${c - 24},${c - 52},${clamp01(alpha)})`;
    } else {
      alpha = t > 0.2 && t < 0.92 ? 0.18 + Math.sin(t * 50) * 0.08 : 0;
      ctx.fillStyle = `rgba(190,210,220,${clamp01(alpha)})`;
    }
    ctx.fillRect(x, 0, 1, h);
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;
  tex.needsUpdate = true;
  return tex;
}

export function createGlowTexture(): THREE.CanvasTexture {
  const size = 128;
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("2D context unavailable");
  const g = ctx.createRadialGradient(64, 64, 0, 64, 64, 64);
  g.addColorStop(0, "rgba(255, 244, 210, 0.95)");
  g.addColorStop(0.22, "rgba(255, 196, 90, 0.45)");
  g.addColorStop(0.55, "rgba(255, 150, 50, 0.12)");
  g.addColorStop(1, "rgba(255, 120, 40, 0)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, size, size);
  const tex = new THREE.CanvasTexture(canvas);
  tex.needsUpdate = true;
  return tex;
}
