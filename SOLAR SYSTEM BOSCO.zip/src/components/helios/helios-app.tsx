import { Canvas } from "@react-three/fiber";
import { useEffect } from "react";
import * as THREE from "three";
import { useSim } from "@/lib/sim-store";
import { Overlay } from "./overlay";
import { Scene } from "./scene";
import { WorldLabels } from "./labels";

export default function HeliosApp() {
  useEffect(() => {
    const api = {
      focus: (id: string) => useSim.getState().focus(id),
      pause: () => useSim.getState().setPaused(true),
      play: () => useSim.getState().setPaused(false),
      reset: () => useSim.getState().resetView(),
      getState: () => useSim.getState(),
    };
    (window as Window & { __helios?: typeof api }).__helios = api;
    return () => {
      delete (window as Window & { __helios?: typeof api }).__helios;
    };
  }, []);

  return (
    <main className="relative h-dvh w-full touch-none overflow-hidden bg-background">
      <Canvas
        className="h-full w-full bg-background"
        camera={{ position: [11, 15, 34], fov: 42, near: 0.12, far: 400 }}
        dpr={[1, 1.75]}
        gl={{
          antialias: true,
          powerPreference: "high-performance",
          toneMapping: THREE.ACESFilmicToneMapping,
          toneMappingExposure: 1.05,
        }}
        onCreated={({ gl }) => {
          gl.setClearColor("#07080c", 1);
        }}
        resize={{ scroll: false }}
      >
        <Scene />
      </Canvas>
      <WorldLabels />
      <Overlay />
    </main>
  );
}
