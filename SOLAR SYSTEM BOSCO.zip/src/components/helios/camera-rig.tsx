import { OrbitControls } from "@react-three/drei";
import { useFrame, useThree } from "@react-three/fiber";
import { useEffect, useRef } from "react";
import * as THREE from "three";
import { getBody } from "@/lib/body-registry";
import { focusDistance } from "@/lib/bodies";
import { useSim } from "@/lib/sim-store";
import type { OrbitControls as OrbitControlsImpl } from "three-stdlib";

const wanted = new THREE.Vector3();
const follow = new THREE.Vector3();
const prevFollow = new THREE.Vector3();
const offset = new THREE.Vector3();
const goal = new THREE.Vector3();
const radial = new THREE.Vector3();

function daysideCamera(target: THREE.Vector3, radius: number, focusedId: string, out: THREE.Vector3) {
  if (focusedId === "system" || target.lengthSq() < 0.2) {
    out.set(12, 16, 34).setLength(radius);
    return;
  }
  radial.copy(target);
  const distFromSun = radial.length();
  radial.normalize();
  if (distFromSun < radius + 4.2) {
    out.copy(radial).multiplyScalar(radius * 0.4);
    out.y += radius * 0.48;
    out.add(target);
    return;
  }
  out.copy(target).addScaledVector(radial, -radius);
  out.y += radius * 0.3;
}

export function CameraRig() {
  const focusedId = useSim((s) => s.focusedId);
  const controlsRef = useRef<OrbitControlsImpl>(null);
  const { camera } = useThree();
  const zooming = useRef(true);
  const desiredRadius = useRef(focusDistance("system"));
  const initialized = useRef(false);

  useEffect(() => {
    desiredRadius.current = focusDistance(focusedId);
    zooming.current = true;
  }, [focusedId]);

  useFrame((_, delta) => {
    const d = Math.min(delta, 0.1);
    const controls = controlsRef.current;
    if (!controls) return;

    const object = focusedId === "system" ? undefined : getBody(focusedId);
    if (object) object.getWorldPosition(wanted);
    else wanted.set(0, 0, 0);

    if (!initialized.current) {
      follow.copy(wanted);
      prevFollow.copy(wanted);
      initialized.current = true;
    }

    const catchUp = zooming.current ? 1 - Math.exp(-3.1 * d) : 1 - Math.exp(-10 * d);
    follow.lerp(wanted, catchUp);

    offset.copy(follow).sub(prevFollow);
    camera.position.add(offset);
    controls.target.copy(follow);
    prevFollow.copy(follow);

    if (zooming.current) {
      daysideCamera(follow, desiredRadius.current, focusedId, goal);
      camera.position.lerp(goal, 1 - Math.exp(-2.5 * d));
      if (camera.position.distanceTo(goal) < 0.14) zooming.current = false;
    }
  });

  return (
    <OrbitControls
      ref={controlsRef}
      makeDefault
      enableDamping
      dampingFactor={0.08}
      enablePan={false}
      minDistance={0.6}
      maxDistance={90}
      minPolarAngle={0.12}
      maxPolarAngle={Math.PI * 0.9}
    />
  );
}
