import { useFrame } from "@react-three/fiber";
import { useLayoutEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { BODIES, SECONDS_PER_YEAR } from "@/lib/bodies";
import { simClock, useSim } from "@/lib/sim-store";
import { CelestialBody } from "./celestial-body";
import { CameraRig } from "./camera-rig";
import { LabelProjector } from "./labels";

const dummy = new THREE.Object3D();

function Starfield({ count }: { count: number }) {
  const geometry = useMemo(() => {
    const positions = new Float32Array(count * 3);
    const colors = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      const r = 50 + Math.random() * 130;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      positions[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      positions[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
      positions[i * 3 + 2] = r * Math.cos(phi);
      const tint = 0.82 + Math.random() * 0.18;
      colors[i * 3] = tint;
      colors[i * 3 + 1] = tint * (0.95 + Math.random() * 0.05);
      colors[i * 3 + 2] = tint;
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    geo.setAttribute("color", new THREE.BufferAttribute(colors, 3));
    return geo;
  }, [count]);

  useEffectDispose(geometry);

  return (
    <points geometry={geometry} frustumCulled={false}>
      <pointsMaterial
        size={0.42}
        vertexColors
        sizeAttenuation
        transparent
        opacity={0.9}
        depthWrite={false}
      />
    </points>
  );
}

function useEffectDispose(geometry: THREE.BufferGeometry) {
  useLayoutEffect(() => () => geometry.dispose(), [geometry]);
}

function AsteroidBelt() {
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const count = 420;
  const seeds = useMemo(() => {
    const arr = new Float32Array(count * 4);
    for (let i = 0; i < count; i++) {
      const t = Math.random() * Math.PI * 2;
      const r = 12.2 + Math.random() * 2.4;
      arr[i * 4] = t;
      arr[i * 4 + 1] = r;
      arr[i * 4 + 2] = (Math.random() - 0.5) * 0.35;
      arr[i * 4 + 3] = 0.012 + Math.random() * 0.03;
    }
    return arr;
  }, []);

  useLayoutEffect(() => {
    const mesh = meshRef.current;
    if (!mesh) return;
    for (let i = 0; i < count; i++) {
      const t = seeds[i * 4]!;
      const r = seeds[i * 4 + 1]!;
      const y = seeds[i * 4 + 2]!;
      const s = seeds[i * 4 + 3]!;
      dummy.position.set(Math.cos(t) * r, y, Math.sin(t) * r);
      dummy.rotation.set(t, t * 0.4, t * 1.3);
      dummy.scale.setScalar(s);
      dummy.updateMatrix();
      mesh.setMatrixAt(i, dummy.matrix);
    }
    mesh.instanceMatrix.needsUpdate = true;
  }, [count, seeds]);

  const groupRef = useRef<THREE.Group>(null);
  useFrame(() => {
    if (groupRef.current) {
      groupRef.current.rotation.y = simClock.years * 0.12;
    }
  });

  return (
    <group ref={groupRef}>
      <instancedMesh ref={meshRef} args={[undefined, undefined, count]}>
        <icosahedronGeometry args={[1, 0]} />
        <meshStandardMaterial color="#6a645e" roughness={0.95} metalness={0.08} />
      </instancedMesh>
    </group>
  );
}

export function Scene() {
  const roots = useMemo(
    () => BODIES.filter((b) => b.parentId === null || b.parentId === "sun"),
    [],
  );
  const starCount = typeof window !== "undefined" && window.innerWidth < 640 ? 2800 : 5600;

  useFrame((_, delta) => {
    const d = Math.min(delta, 0.1);
    const { paused, timeScale } = useSim.getState();
    if (!paused) simClock.years += (d * timeScale) / SECONDS_PER_YEAR;
  });

  return (
    <>
      <color attach="background" args={["#07080c"]} />
      <ambientLight intensity={0.26} color="#9aa6bc" />
      <hemisphereLight args={["#c5d0e0", "#0c0806", 0.22]} />
      <Starfield count={starCount} />
      {roots.map((body) => (
        <CelestialBody key={body.id} body={body} />
      ))}
      <AsteroidBelt />
      <CameraRig />
      <LabelProjector />
    </>
  );
}
