import { Line } from "@react-three/drei";
import { useFrame } from "@react-three/fiber";
import { useEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { registerBody } from "@/lib/body-registry";
import {
  childrenOf,
  keplerRadius,
  makeOrbitPoints,
  type CelestialBody as BodyData,
} from "@/lib/bodies";
import {
  createBodyTexture,
  createCloudTexture,
  createRingTexture,
} from "@/lib/planet-textures";
import { simClock, useSim } from "@/lib/sim-store";

function noopRaycast() {}


function PlanetMesh({ body }: { body: BodyData }) {
  const meshRef = useRef<THREE.Mesh>(null);
  const cloudRef = useRef<THREE.Mesh>(null);
  const textures = useMemo(() => {
    const map = createBodyTexture(body.id, body.kind === "planet" ? 384 : 256);
    const clouds = body.clouds ? createCloudTexture(256) : null;
    const rings = body.rings ? createRingTexture(body.rings.kind) : null;
    return { map, clouds, rings };
  }, [body]);

  useEffect(() => {
    return () => {
      textures.map.dispose();
      textures.clouds?.dispose();
      textures.rings?.dispose();
    };
  }, [textures]);

  useFrame(() => {
    const years = simClock.years;
    if (meshRef.current && body.spinPeriod !== 0) {
      meshRef.current.rotation.y = (years / body.spinPeriod) * Math.PI * 2;
    }
    if (cloudRef.current) {
      cloudRef.current.rotation.y = (years / (body.spinPeriod * 0.85 || 0.06)) * Math.PI * 2;
    }
  });

  const segments = body.radius > 0.5 ? 48 : 32;
  const tilt = (body.tilt * Math.PI) / 180;

  return (
    <group rotation={[0, 0, tilt]}>
      <mesh ref={meshRef} castShadow={false}>
        <sphereGeometry args={[body.radius, segments, segments]} />
        <meshStandardMaterial
          map={textures.map}
          color="#ffffff"
          roughness={body.kind === "star" ? 0.4 : 0.72}
          metalness={0.04}
        />
      </mesh>
      {textures.clouds ? (
        <mesh ref={cloudRef} scale={1.018} raycast={noopRaycast}>
          <sphereGeometry args={[body.radius, 32, 32]} />
          <meshStandardMaterial
            map={textures.clouds}
            transparent
            depthWrite={false}
            roughness={1}
            metalness={0}
          />
        </mesh>
      ) : null}
      {body.atmosphere ? (
        <mesh scale={1.06} raycast={noopRaycast}>
          <sphereGeometry args={[body.radius, 24, 24]} />
          <meshBasicMaterial
            color={body.atmosphere}
            transparent
            opacity={body.id === "earth" ? 0.1 : 0.14}
            side={THREE.BackSide}
            depthWrite={false}
          />
        </mesh>
      ) : null}
      {body.rings && textures.rings ? (
        <mesh rotation={[Math.PI / 2, 0, 0]} raycast={noopRaycast}>
          <ringGeometry args={[body.radius * body.rings.inner, body.radius * body.rings.outer, 96]} />
          <meshStandardMaterial
            map={textures.rings}
            transparent
            side={THREE.DoubleSide}
            depthWrite={false}
            roughness={0.55}
            metalness={0.08}
            emissive={body.rings.kind === "saturn" ? "#3a3220" : "#1a2428"}
            emissiveIntensity={0.35}
          />
        </mesh>
      ) : null}
    </group>
  );
}

function SunMesh({ body }: { body: BodyData }) {
  const glow = useMemo(() => {
    const canvas = document.createElement("canvas");
    canvas.width = 128;
    canvas.height = 128;
    const ctx = canvas.getContext("2d");
    if (!ctx) return null;
    const g = ctx.createRadialGradient(64, 64, 0, 64, 64, 64);
    g.addColorStop(0, "rgba(255, 244, 210, 0.95)");
    g.addColorStop(0.22, "rgba(255, 196, 90, 0.45)");
    g.addColorStop(0.55, "rgba(255, 150, 50, 0.12)");
    g.addColorStop(1, "rgba(255, 120, 40, 0)");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, 128, 128);
    const tex = new THREE.CanvasTexture(canvas);
    tex.needsUpdate = true;
    return tex;
  }, []);

  useEffect(() => () => glow?.dispose(), [glow]);

  const material = useMemo(
    () =>
      new THREE.ShaderMaterial({
        toneMapped: false,
        uniforms: { uTime: { value: 0 } },
        vertexShader: `
          varying vec2 vUv;
          varying vec3 vNormal;
          void main() {
            vUv = uv;
            vNormal = normalize(normalMatrix * normal);
            gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
          }
        `,
        fragmentShader: `
          uniform float uTime;
          varying vec2 vUv;
          varying vec3 vNormal;
          void main() {
            float n = sin(vUv.y * 18.0 + uTime * 0.45) * 0.5 + 0.5;
            n += sin(vUv.x * 22.0 - uTime * 0.28 + n) * 0.22;
            vec3 dark = vec3(0.95, 0.40, 0.07);
            vec3 light = vec3(1.0, 0.93, 0.58);
            vec3 col = mix(dark, light, clamp(n, 0.0, 1.0));
            float rim = pow(1.0 - abs(vNormal.z), 1.35);
            col += vec3(1.0, 0.72, 0.22) * rim * 0.28;
            gl_FragColor = vec4(col, 1.0);
          }
        `,
      }),
    [],
  );

  useEffect(() => () => material.dispose(), [material]);

  useFrame((_, delta) => {
    const paused = useSim.getState().paused;
    const scale = useSim.getState().timeScale;
    if (!paused) material.uniforms.uTime.value += Math.min(delta, 0.1) * Math.min(scale, 4);
  });

  return (
    <group>
      <mesh material={material}>
        <sphereGeometry args={[body.radius, 48, 48]} />
      </mesh>
      <mesh scale={1.12} raycast={noopRaycast}>
        <sphereGeometry args={[body.radius, 32, 32]} />
        <meshBasicMaterial color="#ffb24a" transparent opacity={0.16} depthWrite={false} />
      </mesh>
      {glow ? (
        <sprite scale={[body.radius * 6.4, body.radius * 6.4, 1]} raycast={noopRaycast}>
          <spriteMaterial
            map={glow}
            transparent
            depthWrite={false}
            blending={THREE.AdditiveBlending}
          />
        </sprite>
      ) : null}
      <pointLight color="#fff4dc" intensity={95} distance={90} decay={0.55} />
    </group>
  );
}

export function CelestialBody({ body }: { body: BodyData }) {
  const pivotRef = useRef<THREE.Group>(null);
  const focus = useSim((s) => s.focus);
  const focusedId = useSim((s) => s.focusedId);
  const showOrbits = useSim((s) => s.showOrbits);
  const moons = useMemo(() => childrenOf(body.id).filter((child) => child.kind === "moon"), [body.id]);
  const orbitPts = useMemo(
    () => (body.orbit > 0 ? makeOrbitPoints(body.orbit, body.eccentricity) : null),
    [body],
  );
  const inc = (body.inclination * Math.PI) / 180;
  const lan = (body.lan * Math.PI) / 180;

  useFrame(() => {
    const group = pivotRef.current;
    if (!group || body.orbit <= 0) return;
    const theta = body.phase + (simClock.years / body.period) * Math.PI * 2;
    const r = keplerRadius(body.orbit, body.eccentricity, theta);
    group.position.set(Math.cos(theta) * r, 0, Math.sin(theta) * r);
  });

  const onClick = (event: { stopPropagation: () => void }) => {
    event.stopPropagation();
    focus(body.id);
  };

  const isFocused = focusedId === body.id;

  const inner = (
    <group
      ref={(el) => {
        registerBody(body.id, el);
      }}
    >
      <group
        onClick={onClick}
        onPointerOver={() => {
          document.body.style.cursor = "pointer";
        }}
        onPointerOut={() => {
          document.body.style.cursor = "";
        }}
      >
        {body.kind === "star" ? <SunMesh body={body} /> : <PlanetMesh body={body} />}
      </group>
      {moons.map((moon) => (
        <CelestialBody key={moon.id} body={moon} />
      ))}
    </group>
  );

  if (body.orbit <= 0) {
    return inner;
  }

  return (
    <group rotation={[0, lan, 0]}>
      <group rotation={[inc, 0, 0]}>
        {showOrbits && orbitPts ? (
          <Line
            points={orbitPts}
            color={body.color}
            lineWidth={isFocused ? 1.7 : body.kind === "moon" ? 0.7 : 1.05}
            transparent
            opacity={isFocused ? 0.7 : body.kind === "moon" ? 0.16 : 0.28}
            depthWrite={false}
            raycast={noopRaycast}
          />
        ) : null}
        <group ref={pivotRef}>{inner}</group>
      </group>
    </group>
  );
}
