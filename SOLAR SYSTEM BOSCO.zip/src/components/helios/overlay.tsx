import { Pause, Play, RotateCcw } from "lucide-react";
import { useEffect, useState } from "react";
import { BODY_BY_ID, PICKER_BODIES, childrenOf } from "@/lib/bodies";
import {
  formatTimeScale,
  scaleToSlider,
  simClock,
  sliderToScale,
  useSim,
} from "@/lib/sim-store";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { cn } from "@/lib/utils";

function useSimYears() {
  const [years, setYears] = useState(0);
  useEffect(() => {
    const id = window.setInterval(() => setYears(simClock.years), 200);
    return () => window.clearInterval(id);
  }, []);
  return years;
}

export function Overlay() {
  const paused = useSim((s) => s.paused);
  const timeScale = useSim((s) => s.timeScale);
  const showLabels = useSim((s) => s.showLabels);
  const showOrbits = useSim((s) => s.showOrbits);
  const focusedId = useSim((s) => s.focusedId);
  const selectedId = useSim((s) => s.selectedId);
  const togglePaused = useSim((s) => s.togglePaused);
  const setTimeScale = useSim((s) => s.setTimeScale);
  const setShowLabels = useSim((s) => s.setShowLabels);
  const setShowOrbits = useSim((s) => s.setShowOrbits);
  const focus = useSim((s) => s.focus);
  const resetView = useSim((s) => s.resetView);
  const years = useSimYears();
  const selected = selectedId ? BODY_BY_ID[selectedId] : null;
  const moons = selected ? childrenOf(selected.id).filter((b) => b.kind === "moon") : [];
  const parent = selected?.parentId ? BODY_BY_ID[selected.parentId] : null;

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.metaKey || event.ctrlKey || event.altKey) return;
      if (event.code === "Space") {
        event.preventDefault();
        togglePaused();
      } else if (event.key === "Escape" || event.key === "0") {
        resetView();
      } else if (event.key === "[" || event.key === "-") {
        setTimeScale(Math.max(0.25, timeScale / 2));
      } else if (event.key === "]" || event.key === "=" || event.key === "+") {
        setTimeScale(Math.min(48, timeScale * 2));
      } else if (event.key === "l" || event.key === "L") {
        setShowLabels(!showLabels);
      } else if (event.key === "o" || event.key === "O") {
        setShowOrbits(!showOrbits);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [togglePaused, resetView, setTimeScale, timeScale, showLabels, showOrbits, setShowLabels, setShowOrbits]);

  return (
    <div className="pointer-events-none absolute inset-0 z-10 p-3 text-foreground md:p-5">
      <header className="pointer-events-none flex items-start justify-between gap-4">
        <div>
          <p className="font-sans text-[10px] tracking-[0.28em] text-muted-foreground uppercase">
            Observatory
          </p>
          <h1 className="font-serif text-3xl leading-none text-foreground italic md:text-4xl">Helios</h1>
        </div>
        <div className="pointer-events-auto hidden items-center gap-3 rounded-xl bg-card/90 px-3 py-2 shadow-[var(--shadow-border)] md:flex">
          <span className="font-sans text-[11px] tracking-[0.18em] text-muted-foreground uppercase">
            Elapsed
          </span>
          <span className="font-sans text-sm tabular-nums text-foreground">
            {years < 10 ? years.toFixed(2) : years.toFixed(1)} yr
          </span>
        </div>
      </header>

      {selected ? (
        <aside
          className="helios-panel pointer-events-auto absolute top-20 right-3 hidden w-72 max-w-[calc(100%-1.5rem)] flex-col gap-3 rounded-2xl bg-card/92 p-4 shadow-[var(--shadow-border)] md:flex"
          aria-live="polite"
        >
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="font-sans text-[10px] tracking-[0.22em] text-muted-foreground uppercase">
                {selected.kind}
              </p>
              <h2 className="font-serif text-2xl leading-tight italic">{selected.name}</h2>
            </div>
            <Button variant="ghost" size="icon-sm" onClick={resetView} aria-label="Return to system view">
              <RotateCcw />
            </Button>
          </div>
          <p className="text-sm leading-relaxed text-muted-foreground">{selected.description}</p>
          <dl className="grid grid-cols-2 gap-x-3 gap-y-2">
            {selected.facts.map((fact) => (
              <div key={fact.label}>
                <dt className="text-[10px] tracking-[0.16em] text-subtle uppercase">{fact.label}</dt>
                <dd className="text-sm text-foreground">{fact.value}</dd>
              </div>
            ))}
          </dl>
          {parent && parent.id !== "sun" ? (
            <Button variant="outline" size="sm" onClick={() => focus(parent.id)}>
              Back to {parent.name}
            </Button>
          ) : null}
          {moons.length > 0 ? (
            <div className="flex flex-wrap gap-1.5">
              {moons.map((moon) => (
                <button
                  key={moon.id}
                  type="button"
                  onClick={() => focus(moon.id)}
                  className={cn(
                    "h-8 rounded-md px-2.5 text-xs text-muted-foreground transition-colors duration-[var(--motion-quick)] hover:bg-muted hover:text-foreground",
                    focusedId === moon.id && "bg-muted text-foreground",
                  )}
                >
                  {moon.name}
                </button>
              ))}
            </div>
          ) : null}
        </aside>
      ) : null}

      <footer className="pointer-events-auto absolute right-3 bottom-3 left-3 flex flex-col gap-2 md:right-5 md:bottom-5 md:left-5">
        {selected ? (
          <div className="helios-panel rounded-2xl bg-card/94 p-3 shadow-[var(--shadow-border)] md:hidden">
            <div className="flex items-baseline justify-between gap-2">
              <h2 className="font-serif text-xl italic">{selected.name}</h2>
              <span className="text-[10px] tracking-[0.16em] text-muted-foreground uppercase">
                {selected.kind}
              </span>
            </div>
            <p className="mt-1 line-clamp-3 text-xs leading-relaxed text-muted-foreground">
              {selected.description}
            </p>
            <dl className="mt-2 grid grid-cols-2 gap-2">
              {selected.facts.slice(0, 4).map((fact) => (
                <div key={fact.label}>
                  <dt className="text-[10px] tracking-[0.14em] text-subtle uppercase">{fact.label}</dt>
                  <dd className="text-xs text-foreground">{fact.value}</dd>
                </div>
              ))}
            </dl>
          </div>
        ) : null}
        <div className="flex gap-2 overflow-x-auto no-scrollbar pb-0.5">
          <button
            type="button"
            onClick={resetView}
            className={cn(
              "h-11 shrink-0 rounded-lg px-3 text-xs tracking-[0.12em] uppercase transition-colors duration-[var(--motion-quick)]",
              focusedId === "system"
                ? "bg-primary text-primary-foreground"
                : "bg-card/90 text-muted-foreground shadow-[var(--shadow-border)] hover:text-foreground",
            )}
          >
            System
          </button>
          {PICKER_BODIES.map((body) => (
            <button
              key={body.id}
              type="button"
              onClick={() => focus(body.id)}
              className={cn(
                "flex h-11 shrink-0 items-center gap-2 rounded-lg px-3 text-xs transition-colors duration-[var(--motion-quick)]",
                focusedId === body.id
                  ? "bg-primary text-primary-foreground"
                  : "bg-card/90 text-muted-foreground shadow-[var(--shadow-border)] hover:text-foreground",
              )}
            >
              <span
                className="size-2 rounded-full"
                style={{ backgroundColor: body.color }}
                aria-hidden
              />
              {body.name}
            </button>
          ))}
        </div>

        <div className="flex flex-col gap-3 rounded-2xl bg-card/92 p-3 shadow-[var(--shadow-border)] md:flex-row md:items-center md:gap-5 md:px-4">
          <div className="flex items-center gap-2">
            <Button
              variant="secondary"
              size="icon"
              onClick={togglePaused}
              aria-label={paused ? "Resume simulation" : "Pause simulation"}
              aria-pressed={paused}
            >
              {paused ? <Play className="ml-0.5" /> : <Pause />}
            </Button>
            <div className="min-w-0 flex-1 md:w-56 md:flex-none">
              <div className="mb-1 flex items-center justify-between gap-2">
                <span className="text-[10px] tracking-[0.18em] text-muted-foreground uppercase">Speed</span>
                <span className="text-xs tabular-nums text-foreground">{formatTimeScale(timeScale)}</span>
              </div>
              <Slider
                min={0}
                max={1}
                step={0.01}
                value={[scaleToSlider(timeScale)]}
                onValueChange={(v) => setTimeScale(sliderToScale(v[0] ?? 0.5))}
                aria-label="Simulation speed"
              />
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-1.5 md:ml-auto">
            <ToggleChip pressed={showLabels} onPressedChange={setShowLabels} label="Names" />
            <ToggleChip pressed={showOrbits} onPressedChange={setShowOrbits} label="Orbits" />
            <Button variant="ghost" size="sm" onClick={resetView} className="hidden md:inline-flex">
              Reset view
            </Button>
            <span className="hidden text-[11px] text-subtle md:inline">
              Drag to orbit · scroll to zoom · click a world
            </span>
          </div>
        </div>
      </footer>
    </div>
  );
}

function ToggleChip({
  pressed,
  onPressedChange,
  label,
}: {
  pressed: boolean;
  onPressedChange: (next: boolean) => void;
  label: string;
}) {
  return (
    <button
      type="button"
      aria-pressed={pressed}
      onClick={() => onPressedChange(!pressed)}
      className={cn(
        "h-9 rounded-md px-3 text-xs transition-colors duration-[var(--motion-quick)]",
        pressed ? "bg-muted text-foreground" : "text-muted-foreground hover:bg-muted hover:text-foreground",
      )}
    >
      {label}
    </button>
  );
}
