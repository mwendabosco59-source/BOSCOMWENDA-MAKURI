import { useFrame } from "@react-three/fiber";
import { useEffect, useState } from "react";
import * as THREE from "three";
import { BODIES } from "@/lib/bodies";
import { getBody } from "@/lib/body-registry";
import { screenLabels } from "@/lib/label-state";
import { useSim } from "@/lib/sim-store";

const world = new THREE.Vector3();
const camPos = new THREE.Vector3();

export function LabelProjector() {
  useFrame(({ camera }) => {
    const { showLabels, focusedId } = useSim.getState();
    camera.getWorldPosition(camPos);
    for (let i = 0; i < BODIES.length; i++) {
      const body = BODIES[i]!;
      let slot = screenLabels[i];
      if (!slot) {
        slot = { id: body.id, name: body.name, x: 0.5, y: 0.5, visible: false };
        screenLabels[i] = slot;
      }
      const object = getBody(body.id);
      if (!showLabels || !object) {
        slot.visible = false;
        continue;
      }
      object.getWorldPosition(world);
      const dist = camPos.distanceTo(world);
      world.project(camera);
      const isMoon = body.kind === "moon";
      const related = body.parentId === focusedId || body.id === focusedId;
      const inRange = isMoon
        ? related && dist < 14 && dist > body.radius * 3
        : dist > body.radius * 3.8 && dist < 68;
      const inFront = world.z > -1 && world.z < 1;
      const x = world.x * 0.5 + 0.5;
      const y = -world.y * 0.5 + 0.5 - Math.min(0.045, 0.012 + body.radius / Math.max(dist, 0.2) * 0.35);
      slot.x = x;
      slot.y = y;
      slot.visible = Boolean(inRange && inFront && x > 0.03 && x < 0.97 && y > 0.06 && y < 0.78);
    }
  });
  return null;
}

export function WorldLabels() {
  const show = useSim((s) => s.showLabels);
  const [, setTick] = useState(0);

  useEffect(() => {
    if (!show) return;
    const id = window.setInterval(() => setTick((n) => n + 1), 80);
    return () => window.clearInterval(id);
  }, [show]);

  if (!show) return null;

  return (
    <div className="pointer-events-none absolute inset-0 z-[5]">
      {screenLabels.map((label) =>
        label.visible ? (
          <div
            key={label.id}
            className="absolute -translate-x-1/2 -translate-y-full rounded-md bg-background/55 px-1.5 py-0.5 font-sans text-[10px] tracking-[0.16em] text-foreground/90 uppercase"
            style={{ left: `${label.x * 100}%`, top: `${label.y * 100}%` }}
          >
            {label.name}
          </div>
        ) : null,
      )}
    </div>
  );
}
