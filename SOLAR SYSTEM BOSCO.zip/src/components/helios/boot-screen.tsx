export function BootScreen() {
  return (
    <main className="flex h-dvh w-full flex-col items-center justify-center bg-background text-foreground">
      <p className="text-[10px] tracking-[0.32em] text-muted-foreground uppercase">Observatory</p>
      <h1 className="mt-2 font-serif text-5xl italic">Helios</h1>
      <p className="mt-3 text-sm text-muted-foreground">Lighting the inner system</p>
    </main>
  );
}
