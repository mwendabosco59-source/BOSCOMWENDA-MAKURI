import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, r as Slot, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as useThree, c as BufferAttribute, d as ClampToEdgeWrapping, f as Object3D, g as Vector3, h as ShaderMaterial, i as useFrame, l as BufferGeometry, m as SRGBColorSpace, n as Line, p as RepeatWrapping, r as Canvas, t as OrbitControls, u as CanvasTexture } from "../_libs/@react-three/drei+[...].mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { i as Pause, n as RotateCcw, r as Play } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider$1 } from "../_libs/@radix-ui/react-slider+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/helios-app-CLkF64tH.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var useSim = create()(persist((set) => ({
	paused: false,
	timeScale: 1,
	showLabels: true,
	showOrbits: true,
	focusedId: "system",
	selectedId: null,
	togglePaused: () => set((s) => ({ paused: !s.paused })),
	setPaused: (paused) => set({ paused }),
	setTimeScale: (timeScale) => set({ timeScale }),
	setShowLabels: (showLabels) => set({ showLabels }),
	setShowOrbits: (showOrbits) => set({ showOrbits }),
	focus: (id) => set({
		focusedId: id,
		selectedId: id === "system" ? null : id
	}),
	resetView: () => set({
		focusedId: "system",
		selectedId: null
	})
}), {
	name: "helios-observatory",
	partialize: (s) => ({
		timeScale: s.timeScale,
		showLabels: s.showLabels,
		showOrbits: s.showOrbits
	})
}));
var simClock = { years: 0 };
function formatTimeScale(scale) {
	if (scale < 10) return `${scale.toFixed(1).replace(/\.0$/, "")}×`;
	return `${Math.round(scale)}×`;
}
function sliderToScale(t) {
	const logMin = Math.log2(.25);
	return 2 ** (logMin + t * (Math.log2(48) - logMin));
}
function scaleToSlider(scale) {
	const logMin = Math.log2(.25);
	const logMax = Math.log2(48);
	return (Math.log2(Math.min(48, Math.max(.25, scale))) - logMin) / (logMax - logMin);
}
var BODIES = [
	{
		id: "sun",
		name: "Sun",
		parentId: null,
		kind: "star",
		radius: 2.65,
		orbit: 0,
		eccentricity: 0,
		period: 1,
		spinPeriod: .9,
		tilt: 7.25,
		inclination: 0,
		lan: 0,
		phase: 0,
		color: "#ffcc66",
		description: "A G2V yellow dwarf holding the system together. Nearly all of the solar system's mass lives here, pouring light and wind across every orbit.",
		facts: [
			{
				label: "Type",
				value: "G2V star"
			},
			{
				label: "Diameter",
				value: "1.39 million km"
			},
			{
				label: "Surface",
				value: "5,500 °C"
			},
			{
				label: "Age",
				value: "4.6 billion yr"
			}
		]
	},
	{
		id: "mercury",
		name: "Mercury",
		parentId: "sun",
		kind: "planet",
		radius: .17,
		orbit: 5.15,
		eccentricity: .12,
		period: .241,
		spinPeriod: .16,
		tilt: .03,
		inclination: 7,
		lan: 48,
		phase: 1.2,
		color: "#9a9388",
		description: "The innermost world: a cratered, iron-rich messenger with no real atmosphere. Days last longer than years, and the sky never holds a cloud.",
		facts: [
			{
				label: "Class",
				value: "Terrestrial"
			},
			{
				label: "Distance",
				value: "0.39 AU"
			},
			{
				label: "Year",
				value: "88 days"
			},
			{
				label: "Moons",
				value: "None"
			}
		]
	},
	{
		id: "venus",
		name: "Venus",
		parentId: "sun",
		kind: "planet",
		radius: .28,
		orbit: 6.85,
		eccentricity: .04,
		period: .615,
		spinPeriod: -.55,
		tilt: 177.4,
		inclination: 3.4,
		lan: 76,
		phase: 4.1,
		color: "#d9c19a",
		atmosphere: "#e8d4a8",
		description: "Earth's veiled twin, spinning backward under a crushing carbon-dioxide sky. The surface is hotter than Mercury, lit by a jaundiced overcast.",
		facts: [
			{
				label: "Class",
				value: "Terrestrial"
			},
			{
				label: "Distance",
				value: "0.72 AU"
			},
			{
				label: "Year",
				value: "225 days"
			},
			{
				label: "Day",
				value: "243 days, retrograde"
			}
		]
	},
	{
		id: "earth",
		name: "Earth",
		parentId: "sun",
		kind: "planet",
		radius: .3,
		orbit: 8.55,
		eccentricity: .017,
		period: 1,
		spinPeriod: .07,
		tilt: 23.4,
		inclination: 0,
		lan: 0,
		phase: .35,
		color: "#3d7cc4",
		atmosphere: "#7eb7ff",
		clouds: true,
		description: "The living world. Liquid oceans, a shielding magnetic field, and one large moon keep the climate within the narrow band that lets us look back out.",
		facts: [
			{
				label: "Class",
				value: "Terrestrial"
			},
			{
				label: "Distance",
				value: "1.00 AU"
			},
			{
				label: "Year",
				value: "365.25 days"
			},
			{
				label: "Moons",
				value: "1"
			}
		]
	},
	{
		id: "moon",
		name: "Moon",
		parentId: "earth",
		kind: "moon",
		radius: .082,
		orbit: .78,
		eccentricity: .055,
		period: .0748,
		spinPeriod: .0748,
		tilt: 6.7,
		inclination: 5.1,
		lan: 125,
		phase: 2.4,
		color: "#c9c3b6",
		description: "Earth's companion, tidally locked so the same face always turns toward home. Its pull stirs the oceans and steadies our axial tilt.",
		facts: [
			{
				label: "Class",
				value: "Rocky moon"
			},
			{
				label: "Distance",
				value: "384,400 km"
			},
			{
				label: "Period",
				value: "27.3 days"
			},
			{
				label: "Origin",
				value: "Giant impact"
			}
		]
	},
	{
		id: "mars",
		name: "Mars",
		parentId: "sun",
		kind: "planet",
		radius: .2,
		orbit: 10.55,
		eccentricity: .09,
		period: 1.881,
		spinPeriod: .075,
		tilt: 25.2,
		inclination: 1.85,
		lan: 49,
		phase: 5.6,
		color: "#c07a54",
		atmosphere: "#d4a078",
		description: "A cold desert of rusted dust and ancient riverbeds. Ice caps still breathe with the seasons, and the tallest volcano in the system stands silent.",
		facts: [
			{
				label: "Class",
				value: "Terrestrial"
			},
			{
				label: "Distance",
				value: "1.52 AU"
			},
			{
				label: "Year",
				value: "687 days"
			},
			{
				label: "Moons",
				value: "2 (Phobos, Deimos)"
			}
		]
	},
	{
		id: "jupiter",
		name: "Jupiter",
		parentId: "sun",
		kind: "planet",
		radius: .98,
		orbit: 16.4,
		eccentricity: .048,
		period: 11.86,
		spinPeriod: .032,
		tilt: 3.1,
		inclination: 1.3,
		lan: 100,
		phase: 2.8,
		color: "#c4a07a",
		atmosphere: "#e0c49a",
		description: "A failed star of hydrogen and helium, wrapping a family of worlds in radiation and storms. The Great Red Spot has raged for centuries.",
		facts: [
			{
				label: "Class",
				value: "Gas giant"
			},
			{
				label: "Distance",
				value: "5.20 AU"
			},
			{
				label: "Year",
				value: "11.9 years"
			},
			{
				label: "Moons",
				value: "95+"
			}
		]
	},
	{
		id: "io",
		name: "Io",
		parentId: "jupiter",
		kind: "moon",
		radius: .07,
		orbit: 1.45,
		eccentricity: .004,
		period: .0048,
		spinPeriod: .0048,
		tilt: 0,
		inclination: .05,
		lan: 0,
		phase: .4,
		color: "#e6d16a",
		description: "The most volcanic body we know. Jupiter's tides knead Io's interior until sulfur plumes fountain hundreds of kilometres into space.",
		facts: [
			{
				label: "Class",
				value: "Galilean moon"
			},
			{
				label: "Period",
				value: "1.8 days"
			},
			{
				label: "Feature",
				value: "Active volcanoes"
			},
			{
				label: "Discovered",
				value: "1610"
			}
		]
	},
	{
		id: "europa",
		name: "Europa",
		parentId: "jupiter",
		kind: "moon",
		radius: .064,
		orbit: 1.85,
		eccentricity: .009,
		period: .0097,
		spinPeriod: .0097,
		tilt: .1,
		inclination: .47,
		lan: 20,
		phase: 1.7,
		color: "#c9d4de",
		description: "An ice shell over a global ocean. Fractures score the surface like a frozen sea, and that hidden water is one of the best hopes for life nearby.",
		facts: [
			{
				label: "Class",
				value: "Galilean moon"
			},
			{
				label: "Period",
				value: "3.5 days"
			},
			{
				label: "Feature",
				value: "Subsurface ocean"
			},
			{
				label: "Discovered",
				value: "1610"
			}
		]
	},
	{
		id: "ganymede",
		name: "Ganymede",
		parentId: "jupiter",
		kind: "moon",
		radius: .09,
		orbit: 2.32,
		eccentricity: .001,
		period: .0196,
		spinPeriod: .0196,
		tilt: .2,
		inclination: .2,
		lan: 40,
		phase: 3.3,
		color: "#9aa0a8",
		description: "The largest moon in the solar system — bigger than Mercury — and the only one with its own magnetic field, wrapped in grooved ice and dark terrain.",
		facts: [
			{
				label: "Class",
				value: "Galilean moon"
			},
			{
				label: "Period",
				value: "7.2 days"
			},
			{
				label: "Feature",
				value: "Own magnetosphere"
			},
			{
				label: "Discovered",
				value: "1610"
			}
		]
	},
	{
		id: "callisto",
		name: "Callisto",
		parentId: "jupiter",
		kind: "moon",
		radius: .082,
		orbit: 2.92,
		eccentricity: .007,
		period: .0457,
		spinPeriod: .0457,
		tilt: 0,
		inclination: .5,
		lan: 80,
		phase: 5.1,
		color: "#6f6860",
		description: "An ancient, cratered ice world at the edge of Jupiter's radiation. It has barely changed since the late heavy bombardment.",
		facts: [
			{
				label: "Class",
				value: "Galilean moon"
			},
			{
				label: "Period",
				value: "16.7 days"
			},
			{
				label: "Feature",
				value: "Oldest surface"
			},
			{
				label: "Discovered",
				value: "1610"
			}
		]
	},
	{
		id: "saturn",
		name: "Saturn",
		parentId: "sun",
		kind: "planet",
		radius: .82,
		orbit: 21.6,
		eccentricity: .054,
		period: 29.46,
		spinPeriod: .036,
		tilt: 26.7,
		inclination: 2.5,
		lan: 113,
		phase: .9,
		color: "#e0c48a",
		atmosphere: "#ead8a8",
		rings: {
			inner: 1.15,
			outer: 2.45,
			kind: "saturn"
		},
		description: "Pale gold and almost light enough to float on water. Its rings are ice and dust, a razor-thin architecture visible across the outer system.",
		facts: [
			{
				label: "Class",
				value: "Gas giant"
			},
			{
				label: "Distance",
				value: "9.58 AU"
			},
			{
				label: "Year",
				value: "29.5 years"
			},
			{
				label: "Rings",
				value: "Ice, kilometres thin"
			}
		]
	},
	{
		id: "titan",
		name: "Titan",
		parentId: "saturn",
		kind: "moon",
		radius: .088,
		orbit: 2.55,
		eccentricity: .029,
		period: .0437,
		spinPeriod: .0437,
		tilt: 0,
		inclination: .3,
		lan: 15,
		phase: 1.1,
		color: "#c4a06a",
		atmosphere: "#d4b07a",
		description: "A moon with weather. Methane rivers cut through organic haze toward hydrocarbon seas — the only other surface liquid we have walked beside, by proxy.",
		facts: [
			{
				label: "Class",
				value: "Icy moon"
			},
			{
				label: "Period",
				value: "16 days"
			},
			{
				label: "Feature",
				value: "Methane lakes"
			},
			{
				label: "Atmosphere",
				value: "Dense N₂ haze"
			}
		]
	},
	{
		id: "uranus",
		name: "Uranus",
		parentId: "sun",
		kind: "planet",
		radius: .48,
		orbit: 26.2,
		eccentricity: .047,
		period: 84,
		spinPeriod: .05,
		tilt: 97.8,
		inclination: .77,
		lan: 74,
		phase: 3.7,
		color: "#9ad0d4",
		atmosphere: "#b7e0e2",
		rings: {
			inner: 1.2,
			outer: 1.85,
			kind: "uranus"
		},
		description: "An ice giant rolled onto its side, so its poles take turns facing the Sun for decades. Pale methane air gives it that quiet sea-glass colour.",
		facts: [
			{
				label: "Class",
				value: "Ice giant"
			},
			{
				label: "Distance",
				value: "19.2 AU"
			},
			{
				label: "Year",
				value: "84 years"
			},
			{
				label: "Tilt",
				value: "98°"
			}
		]
	},
	{
		id: "neptune",
		name: "Neptune",
		parentId: "sun",
		kind: "planet",
		radius: .46,
		orbit: 30.6,
		eccentricity: .009,
		period: 164.8,
		spinPeriod: .046,
		tilt: 28.3,
		inclination: 1.77,
		lan: 131,
		phase: 5.9,
		color: "#3a6fd4",
		atmosphere: "#5b8eec",
		description: "The last giant, found with mathematics before a telescope. Dark storms and the fastest winds in the system streak a deep, cobalt hydrogen sea.",
		facts: [
			{
				label: "Class",
				value: "Ice giant"
			},
			{
				label: "Distance",
				value: "30.1 AU"
			},
			{
				label: "Year",
				value: "165 years"
			},
			{
				label: "Winds",
				value: "Up to 2,000 km/h"
			}
		]
	},
	{
		id: "pluto",
		name: "Pluto",
		parentId: "sun",
		kind: "dwarf",
		radius: .12,
		orbit: 34.8,
		eccentricity: .22,
		period: 248,
		spinPeriod: .017,
		tilt: 122.5,
		inclination: 17.2,
		lan: 110,
		phase: .2,
		color: "#c4b09a",
		description: "A heart-marked world of nitrogen ice at the edge of the Kuiper belt. Its orbit weaves inside Neptune's for part of each long century.",
		facts: [
			{
				label: "Class",
				value: "Dwarf planet"
			},
			{
				label: "Distance",
				value: "39.5 AU avg."
			},
			{
				label: "Year",
				value: "248 years"
			},
			{
				label: "Companion",
				value: "Charon"
			}
		]
	}
];
var BODY_BY_ID = Object.fromEntries(BODIES.map((body) => [body.id, body]));
var PICKER_BODIES = BODIES.filter((body) => body.parentId === "sun" || body.id === "sun");
function childrenOf(id) {
	return BODIES.filter((body) => body.parentId === id);
}
function focusDistance(id) {
	if (id === "system") return 42;
	const body = BODY_BY_ID[id];
	if (!body) return 36;
	const ring = body.rings?.outer ?? 1;
	const extent = Math.max(body.radius, body.radius * ring);
	if (body.kind === "star") return extent * 5.2;
	if (body.kind === "moon") return Math.max(extent * 12, 1.2);
	if (body.id === "saturn") return 7.6;
	if (body.id === "jupiter") return 6.4;
	if (body.id === "uranus" || body.id === "neptune") return 3.8;
	return Math.max(extent * 11.5, 3.4);
}
function keplerRadius(semiMajor, eccentricity, theta) {
	const e = eccentricity;
	return semiMajor * (1 - e * e) / (1 + e * Math.cos(theta));
}
function makeOrbitPoints(orbit, eccentricity, segments = 160) {
	const pts = [];
	for (let i = 0; i <= segments; i++) {
		const theta = i / segments * Math.PI * 2;
		const r = keplerRadius(orbit, eccentricity, theta);
		pts.push([
			Math.cos(theta) * r,
			0,
			Math.sin(theta) * r
		]);
	}
	return pts;
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[color,background-color,box-shadow,opacity,transform] duration-[var(--motion-quick)] ease-[var(--ease-out)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/70 disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 active:scale-[0.98]", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground hover:bg-primary/90",
			secondary: "bg-card text-foreground shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
			ghost: "text-muted-foreground hover:bg-muted hover:text-foreground",
			outline: "border border-border bg-transparent text-foreground hover:bg-card"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-xs",
			icon: "size-11",
			"icon-sm": "size-9"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var Slider = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider$1, {
	ref,
	className: cn("relative flex w-full touch-none items-center select-none", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
		className: "relative h-1 w-full grow overflow-hidden rounded-full bg-muted",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: "absolute h-full bg-accent" })
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, { className: "block size-4 rounded-full bg-accent shadow-[var(--shadow-border)] ring-2 ring-background transition-[box-shadow] duration-[var(--motion-quick)] ease-[var(--ease-out)] hover:shadow-[var(--shadow-border-hover)] focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none" })]
}));
Slider.displayName = Slider$1.displayName;
function useSimYears() {
	const [years, setYears] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => setYears(simClock.years), 200);
		return () => window.clearInterval(id);
	}, []);
	return years;
}
function Overlay() {
	const paused = useSim((s) => s.paused);
	const timeScale = useSim((s) => s.timeScale);
	const showLabels = useSim((s) => s.showLabels);
	const showOrbits = useSim((s) => s.showOrbits);
	const focusedId = useSim((s) => s.focusedId);
	const selectedId = useSim((s) => s.selectedId);
	const togglePaused = useSim((s) => s.togglePaused);
	const setTimeScale = useSim((s) => s.setTimeScale);
	const setShowLabels = useSim((s) => s.setShowLabels);
	const setShowOrbits = useSim((s) => s.setShowOrbits);
	const focus = useSim((s) => s.focus);
	const resetView = useSim((s) => s.resetView);
	const years = useSimYears();
	const selected = selectedId ? BODY_BY_ID[selectedId] : null;
	const moons = selected ? childrenOf(selected.id).filter((b) => b.kind === "moon") : [];
	const parent = selected?.parentId ? BODY_BY_ID[selected.parentId] : null;
	(0, import_react.useEffect)(() => {
		const onKey = (event) => {
			if (event.metaKey || event.ctrlKey || event.altKey) return;
			if (event.code === "Space") {
				event.preventDefault();
				togglePaused();
			} else if (event.key === "Escape" || event.key === "0") resetView();
			else if (event.key === "[" || event.key === "-") setTimeScale(Math.max(.25, timeScale / 2));
			else if (event.key === "]" || event.key === "=" || event.key === "+") setTimeScale(Math.min(48, timeScale * 2));
			else if (event.key === "l" || event.key === "L") setShowLabels(!showLabels);
			else if (event.key === "o" || event.key === "O") setShowOrbits(!showOrbits);
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [
		togglePaused,
		resetView,
		setTimeScale,
		timeScale,
		showLabels,
		showOrbits,
		setShowLabels,
		setShowOrbits
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-none absolute inset-0 z-10 p-3 text-foreground md:p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "pointer-events-none flex items-start justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-sans text-[10px] tracking-[0.28em] text-muted-foreground uppercase",
					children: "Observatory"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-serif text-3xl leading-none text-foreground italic md:text-4xl",
					children: "Helios"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pointer-events-auto hidden items-center gap-3 rounded-xl bg-card/90 px-3 py-2 shadow-[var(--shadow-border)] md:flex",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-sans text-[11px] tracking-[0.18em] text-muted-foreground uppercase",
						children: "Elapsed"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-sans text-sm tabular-nums text-foreground",
						children: [years < 10 ? years.toFixed(2) : years.toFixed(1), " yr"]
					})]
				})]
			}),
			selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "helios-panel pointer-events-auto absolute top-20 right-3 hidden w-72 max-w-[calc(100%-1.5rem)] flex-col gap-3 rounded-2xl bg-card/92 p-4 shadow-[var(--shadow-border)] md:flex",
				"aria-live": "polite",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-sans text-[10px] tracking-[0.22em] text-muted-foreground uppercase",
							children: selected.kind
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-serif text-2xl leading-tight italic",
							children: selected.name
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon-sm",
							onClick: resetView,
							"aria-label": "Return to system view",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm leading-relaxed text-muted-foreground",
						children: selected.description
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
						className: "grid grid-cols-2 gap-x-3 gap-y-2",
						children: selected.facts.map((fact) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-[10px] tracking-[0.16em] text-subtle uppercase",
							children: fact.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "text-sm text-foreground",
							children: fact.value
						})] }, fact.label))
					}),
					parent && parent.id !== "sun" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						onClick: () => focus(parent.id),
						children: ["Back to ", parent.name]
					}) : null,
					moons.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-1.5",
						children: moons.map((moon) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => focus(moon.id),
							className: cn("h-8 rounded-md px-2.5 text-xs text-muted-foreground transition-colors duration-[var(--motion-quick)] hover:bg-muted hover:text-foreground", focusedId === moon.id && "bg-muted text-foreground"),
							children: moon.name
						}, moon.id))
					}) : null
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "pointer-events-auto absolute right-3 bottom-3 left-3 flex flex-col gap-2 md:right-5 md:bottom-5 md:left-5",
				children: [
					selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "helios-panel rounded-2xl bg-card/94 p-3 shadow-[var(--shadow-border)] md:hidden",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-baseline justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-serif text-xl italic",
									children: selected.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] tracking-[0.16em] text-muted-foreground uppercase",
									children: selected.kind
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 line-clamp-3 text-xs leading-relaxed text-muted-foreground",
								children: selected.description
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
								className: "mt-2 grid grid-cols-2 gap-2",
								children: selected.facts.slice(0, 4).map((fact) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-[10px] tracking-[0.14em] text-subtle uppercase",
									children: fact.label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "text-xs text-foreground",
									children: fact.value
								})] }, fact.label))
							})
						]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2 overflow-x-auto no-scrollbar pb-0.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: resetView,
							className: cn("h-11 shrink-0 rounded-lg px-3 text-xs tracking-[0.12em] uppercase transition-colors duration-[var(--motion-quick)]", focusedId === "system" ? "bg-primary text-primary-foreground" : "bg-card/90 text-muted-foreground shadow-[var(--shadow-border)] hover:text-foreground"),
							children: "System"
						}), PICKER_BODIES.map((body) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => focus(body.id),
							className: cn("flex h-11 shrink-0 items-center gap-2 rounded-lg px-3 text-xs transition-colors duration-[var(--motion-quick)]", focusedId === body.id ? "bg-primary text-primary-foreground" : "bg-card/90 text-muted-foreground shadow-[var(--shadow-border)] hover:text-foreground"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "size-2 rounded-full",
								style: { backgroundColor: body.color },
								"aria-hidden": true
							}), body.name]
						}, body.id))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-3 rounded-2xl bg-card/92 p-3 shadow-[var(--shadow-border)] md:flex-row md:items-center md:gap-5 md:px-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "secondary",
								size: "icon",
								onClick: togglePaused,
								"aria-label": paused ? "Resume simulation" : "Pause simulation",
								"aria-pressed": paused,
								children: paused ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "ml-0.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, {})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1 md:w-56 md:flex-none",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mb-1 flex items-center justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] tracking-[0.18em] text-muted-foreground uppercase",
										children: "Speed"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs tabular-nums text-foreground",
										children: formatTimeScale(timeScale)
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
									min: 0,
									max: 1,
									step: .01,
									value: [scaleToSlider(timeScale)],
									onValueChange: (v) => setTimeScale(sliderToScale(v[0] ?? .5)),
									"aria-label": "Simulation speed"
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-1.5 md:ml-auto",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleChip, {
									pressed: showLabels,
									onPressedChange: setShowLabels,
									label: "Names"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleChip, {
									pressed: showOrbits,
									onPressedChange: setShowOrbits,
									label: "Orbits"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "sm",
									onClick: resetView,
									className: "hidden md:inline-flex",
									children: "Reset view"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hidden text-[11px] text-subtle md:inline",
									children: "Drag to orbit · scroll to zoom · click a world"
								})
							]
						})]
					})
				]
			})
		]
	});
}
function ToggleChip({ pressed, onPressedChange, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-pressed": pressed,
		onClick: () => onPressedChange(!pressed),
		className: cn("h-9 rounded-md px-3 text-xs transition-colors duration-[var(--motion-quick)]", pressed ? "bg-muted text-foreground" : "text-muted-foreground hover:bg-muted hover:text-foreground"),
		children: label
	});
}
var bodies = /* @__PURE__ */ new Map();
function registerBody(id, object) {
	if (object) bodies.set(id, object);
	else bodies.delete(id);
}
function getBody(id) {
	return bodies.get(id);
}
function hash(x, y) {
	const s = Math.sin(x * 127.1 + y * 311.7) * 43758.5453;
	return s - Math.floor(s);
}
function noise(x, y) {
	const ix = Math.floor(x);
	const iy = Math.floor(y);
	const fx = x - ix;
	const fy = y - iy;
	const ux = fx * fx * (3 - 2 * fx);
	const uy = fy * fy * (3 - 2 * fy);
	return (1 - ux) * ((1 - uy) * hash(ix, iy) + uy * hash(ix, iy + 1)) + ux * ((1 - uy) * hash(ix + 1, iy) + uy * hash(ix + 1, iy + 1));
}
function fbm(x, y, octaves = 5) {
	let v = 0;
	let a = .5;
	let f = 1;
	for (let i = 0; i < octaves; i++) {
		v += a * noise(x * f, y * f);
		a *= .5;
		f *= 2;
	}
	return v;
}
function mix(a, b, t) {
	return a + (b - a) * t;
}
function clamp01(v) {
	return Math.min(1, Math.max(0, v));
}
function setRgb(data, i, r, g, b, a = 255) {
	data[i] = r;
	data[i + 1] = g;
	data[i + 2] = b;
	data[i + 3] = a;
}
function makeCanvas(size) {
	const canvas = document.createElement("canvas");
	canvas.width = size;
	canvas.height = size;
	const ctx = canvas.getContext("2d", { willReadFrequently: true });
	if (!ctx) throw new Error("2D context unavailable");
	return {
		canvas,
		ctx,
		img: ctx.createImageData(size, size)
	};
}
function toTexture(canvas) {
	const tex = new CanvasTexture(canvas);
	tex.colorSpace = SRGBColorSpace;
	tex.anisotropy = 8;
	tex.wrapS = RepeatWrapping;
	tex.wrapT = ClampToEdgeWrapping;
	tex.needsUpdate = true;
	return tex;
}
function paintMercury(data, size) {
	for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
		const u = x / size;
		const v = y / size;
		const c = 118 + fbm(u * 8, v * 5, 4) * 55;
		setRgb(data, (y * size + x) * 4, c, c - 6, c - 14);
	}
	for (let k = 0; k < 48; k++) {
		const cx = hash(k, 3.2) * size;
		const cy = hash(k, 8.7) * size;
		const r = 2 + hash(k, 1.4) * 16;
		const dark = .55 + hash(k, 9.1) * .25;
		const r2 = r * r;
		const x0 = Math.max(0, Math.floor(cx - r));
		const x1 = Math.min(size - 1, Math.ceil(cx + r));
		const y0 = Math.max(0, Math.floor(cy - r));
		const y1 = Math.min(size - 1, Math.ceil(cy + r));
		for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) {
			const dx = x - cx;
			const dy = y - cy;
			const d = dx * dx + dy * dy;
			if (d > r2) continue;
			const t = Math.sqrt(d) / r;
			const i = (y * size + x) * 4;
			const m = mix(dark, 1, t * t);
			data[i] *= m;
			data[i + 1] *= m;
			data[i + 2] *= m;
		}
	}
}
function paintVenus(data, size) {
	for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
		const u = x / size;
		const v = y / size;
		const n = fbm(u * 6 + v * 2, v * 4, 4);
		const streak = Math.sin(v * 14 + n * 4) * .5 + .5;
		const r = 210 + n * 25 + streak * 12;
		const g = 175 + n * 18;
		const b = 120 + n * 10;
		setRgb(data, (y * size + x) * 4, r, g, b);
	}
}
function paintEarth(data, size) {
	for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
		const u = x / size;
		const v = y / size;
		const lat = v * 2 - 1;
		const n = fbm(u * 7, v * 4, 5);
		const land = n > .52 + Math.abs(lat) * .04;
		const ice = Math.abs(lat) > .82 || Math.abs(lat) > .7 && n > .55;
		const i = (y * size + x) * 4;
		if (ice) setRgb(data, i, 230, 236, 242);
		else if (land) {
			if (n > .62 && Math.abs(lat) < .35) setRgb(data, i, 168, 148, 88);
			else setRgb(data, i, 46 + n * 30, 108 + n * 20, 58);
		} else {
			const deep = .35 + n * .25;
			setRgb(data, i, 18 + deep * 20, 52 + deep * 40, 118 + deep * 50);
		}
	}
}
function paintMars(data, size) {
	for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
		const u = x / size;
		const v = y / size;
		const lat = v * 2 - 1;
		const n = fbm(u * 7, v * 5, 5);
		const i = (y * size + x) * 4;
		if (Math.abs(lat) > .86) setRgb(data, i, 232, 228, 220);
		else setRgb(data, i, 168 + n * 50, 78 + n * 28, 48 + n * 16);
	}
}
function paintBands(data, size, palette, spot) {
	for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
		const u = x / size;
		const v = y / size;
		const n = fbm(u * 4, v * 10, 4);
		const band = clamp01(v + (n - .5) * .08);
		const [pr, pg, pb] = palette[Math.min(palette.length - 1, Math.floor(band * palette.length))];
		const wobble = (n - .5) * 18;
		setRgb(data, (y * size + x) * 4, pr + wobble, pg + wobble * .6, pb);
	}
	if (spot) {
		const r2 = spot.r * spot.r;
		for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
			const dx = (x - spot.x * size) / size;
			const dy = (y - spot.y * size) / (size * .55);
			const d = dx * dx * 2.4 + dy * dy;
			if (d > r2) continue;
			const t = 1 - d / r2;
			const i = (y * size + x) * 4;
			data[i] = mix(data[i], spot.color[0], t);
			data[i + 1] = mix(data[i + 1], spot.color[1], t);
			data[i + 2] = mix(data[i + 2], spot.color[2], t);
		}
	}
}
function paintIce(data, size, base) {
	for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
		const u = x / size;
		const v = y / size;
		const n = fbm(u * 5, v * 8, 4);
		setRgb(data, (y * size + x) * 4, base[0] + n * 28, base[1] + n * 22, base[2] + n * 18);
	}
}
function paintMoon(data, size, base) {
	for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
		const u = x / size;
		const v = y / size;
		const n = fbm(u * 9, v * 6, 4);
		setRgb(data, (y * size + x) * 4, base[0] + n * 40, base[1] + n * 38, base[2] + n * 32);
	}
}
function createBodyTexture(id, size = 256) {
	const { canvas, ctx, img } = makeCanvas(size);
	const data = img.data;
	switch (id) {
		case "mercury":
		case "callisto":
			paintMercury(data, size);
			break;
		case "venus":
		case "titan":
			paintVenus(data, size);
			break;
		case "earth":
			paintEarth(data, size);
			break;
		case "mars":
			paintMars(data, size);
			break;
		case "jupiter":
			paintBands(data, size, [
				[
					210,
					176,
					128
				],
				[
					186,
					142,
					96
				],
				[
					228,
					204,
					164
				],
				[
					168,
					122,
					78
				],
				[
					214,
					182,
					136
				],
				[
					152,
					108,
					72
				]
			], {
				x: .62,
				y: .58,
				r: .045,
				color: [
					176,
					72,
					48
				]
			});
			break;
		case "saturn":
			paintBands(data, size, [
				[
					232,
					210,
					150
				],
				[
					214,
					186,
					122
				],
				[
					236,
					220,
					176
				],
				[
					198,
					168,
					108
				],
				[
					220,
					198,
					148
				]
			]);
			break;
		case "uranus":
			paintIce(data, size, [
				140,
				196,
				200
			]);
			break;
		case "neptune":
			paintIce(data, size, [
				42,
				92,
				196
			]);
			break;
		case "pluto":
			paintMars(data, size);
			break;
		case "moon":
			paintMoon(data, size, [
				168,
				162,
				150
			]);
			break;
		case "io":
			paintMoon(data, size, [
				210,
				186,
				72
			]);
			break;
		case "europa":
			paintIce(data, size, [
				186,
				198,
				210
			]);
			break;
		case "ganymede":
			paintMoon(data, size, [
				132,
				128,
				120
			]);
			break;
		default: paintMoon(data, size, [
			160,
			160,
			160
		]);
	}
	ctx.putImageData(img, 0, 0);
	return toTexture(canvas);
}
function createCloudTexture(size = 256) {
	const { canvas, ctx, img } = makeCanvas(size);
	const data = img.data;
	for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
		const u = x / size;
		const v = y / size;
		const n = fbm(u * 8, v * 5, 5);
		const a = n > .58 ? (n - .58) * 420 : 0;
		setRgb(data, (y * size + x) * 4, 245, 248, 252, clamp01(a / 255) * 255);
	}
	ctx.putImageData(img, 0, 0);
	return toTexture(canvas);
}
function createRingTexture(kind) {
	const w = 1024;
	const h = 64;
	const canvas = document.createElement("canvas");
	canvas.width = w;
	canvas.height = h;
	const ctx = canvas.getContext("2d");
	if (!ctx) throw new Error("2D context unavailable");
	for (let x = 0; x < w; x++) {
		const t = x / w;
		let alpha = 0;
		if (kind === "saturn") {
			if (t < .08) alpha = 0;
			else if (t > .44 && t < .5) alpha = .03;
			else alpha = .42 + Math.sin(t * 90) * .16 + Math.sin(t * 17) * .08;
			alpha *= .92;
			const c = 210 + Math.sin(t * 40) * 18;
			ctx.fillStyle = `rgba(${c},${c - 24},${c - 52},${clamp01(alpha)})`;
		} else {
			alpha = t > .2 && t < .92 ? .18 + Math.sin(t * 50) * .08 : 0;
			ctx.fillStyle = `rgba(190,210,220,${clamp01(alpha)})`;
		}
		ctx.fillRect(x, 0, 1, h);
	}
	const tex = new CanvasTexture(canvas);
	tex.colorSpace = SRGBColorSpace;
	tex.anisotropy = 8;
	tex.needsUpdate = true;
	return tex;
}
function noopRaycast() {}
function PlanetMesh({ body }) {
	const meshRef = (0, import_react.useRef)(null);
	const cloudRef = (0, import_react.useRef)(null);
	const textures = (0, import_react.useMemo)(() => {
		return {
			map: createBodyTexture(body.id, body.kind === "planet" ? 384 : 256),
			clouds: body.clouds ? createCloudTexture(256) : null,
			rings: body.rings ? createRingTexture(body.rings.kind) : null
		};
	}, [body]);
	(0, import_react.useEffect)(() => {
		return () => {
			textures.map.dispose();
			textures.clouds?.dispose();
			textures.rings?.dispose();
		};
	}, [textures]);
	useFrame(() => {
		const years = simClock.years;
		if (meshRef.current && body.spinPeriod !== 0) meshRef.current.rotation.y = years / body.spinPeriod * Math.PI * 2;
		if (cloudRef.current) cloudRef.current.rotation.y = years / (body.spinPeriod * .85 || .06) * Math.PI * 2;
	});
	const segments = body.radius > .5 ? 48 : 32;
	const tilt = body.tilt * Math.PI / 180;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		rotation: [
			0,
			0,
			tilt
		],
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				ref: meshRef,
				castShadow: false,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
					body.radius,
					segments,
					segments
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					map: textures.map,
					color: "#ffffff",
					roughness: body.kind === "star" ? .4 : .72,
					metalness: .04
				})]
			}),
			textures.clouds ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				ref: cloudRef,
				scale: 1.018,
				raycast: noopRaycast,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
					body.radius,
					32,
					32
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					map: textures.clouds,
					transparent: true,
					depthWrite: false,
					roughness: 1,
					metalness: 0
				})]
			}) : null,
			body.atmosphere ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				scale: 1.06,
				raycast: noopRaycast,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
					body.radius,
					24,
					24
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshBasicMaterial", {
					color: body.atmosphere,
					transparent: true,
					opacity: body.id === "earth" ? .1 : .14,
					side: 1,
					depthWrite: false
				})]
			}) : null,
			body.rings && textures.rings ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
				rotation: [
					Math.PI / 2,
					0,
					0
				],
				raycast: noopRaycast,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ringGeometry", { args: [
					body.radius * body.rings.inner,
					body.radius * body.rings.outer,
					96
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
					map: textures.rings,
					transparent: true,
					side: 2,
					depthWrite: false,
					roughness: .55,
					metalness: .08,
					emissive: body.rings.kind === "saturn" ? "#3a3220" : "#1a2428",
					emissiveIntensity: .35
				})]
			}) : null
		]
	});
}
function SunMesh({ body }) {
	const glow = (0, import_react.useMemo)(() => {
		const canvas = document.createElement("canvas");
		canvas.width = 128;
		canvas.height = 128;
		const ctx = canvas.getContext("2d");
		if (!ctx) return null;
		const g = ctx.createRadialGradient(64, 64, 0, 64, 64, 64);
		g.addColorStop(0, "rgba(255, 244, 210, 0.95)");
		g.addColorStop(.22, "rgba(255, 196, 90, 0.45)");
		g.addColorStop(.55, "rgba(255, 150, 50, 0.12)");
		g.addColorStop(1, "rgba(255, 120, 40, 0)");
		ctx.fillStyle = g;
		ctx.fillRect(0, 0, 128, 128);
		const tex = new CanvasTexture(canvas);
		tex.needsUpdate = true;
		return tex;
	}, []);
	(0, import_react.useEffect)(() => () => glow?.dispose(), [glow]);
	const material = (0, import_react.useMemo)(() => new ShaderMaterial({
		toneMapped: false,
		uniforms: { uTime: { value: 0 } },
		vertexShader: `
          varying vec2 vUv;
          varying vec3 vNormal;
          void main() {
            vUv = uv;
            vNormal = normalize(normalMatrix * normal);
            gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
          }
        `,
		fragmentShader: `
          uniform float uTime;
          varying vec2 vUv;
          varying vec3 vNormal;
          void main() {
            float n = sin(vUv.y * 18.0 + uTime * 0.45) * 0.5 + 0.5;
            n += sin(vUv.x * 22.0 - uTime * 0.28 + n) * 0.22;
            vec3 dark = vec3(0.95, 0.40, 0.07);
            vec3 light = vec3(1.0, 0.93, 0.58);
            vec3 col = mix(dark, light, clamp(n, 0.0, 1.0));
            float rim = pow(1.0 - abs(vNormal.z), 1.35);
            col += vec3(1.0, 0.72, 0.22) * rim * 0.28;
            gl_FragColor = vec4(col, 1.0);
          }
        `
	}), []);
	(0, import_react.useEffect)(() => () => material.dispose(), [material]);
	useFrame((_, delta) => {
		const paused = useSim.getState().paused;
		const scale = useSim.getState().timeScale;
		if (!paused) material.uniforms.uTime.value += Math.min(delta, .1) * Math.min(scale, 4);
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mesh", {
			material,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				body.radius,
				48,
				48
			] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			scale: 1.12,
			raycast: noopRaycast,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
				body.radius,
				32,
				32
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshBasicMaterial", {
				color: "#ffb24a",
				transparent: true,
				opacity: .16,
				depthWrite: false
			})]
		}),
		glow ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("sprite", {
			scale: [
				body.radius * 6.4,
				body.radius * 6.4,
				1
			],
			raycast: noopRaycast,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("spriteMaterial", {
				map: glow,
				transparent: true,
				depthWrite: false,
				blending: 2
			})
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pointLight", {
			color: "#fff4dc",
			intensity: 95,
			distance: 90,
			decay: .55
		})
	] });
}
function CelestialBody({ body }) {
	const pivotRef = (0, import_react.useRef)(null);
	const focus = useSim((s) => s.focus);
	const focusedId = useSim((s) => s.focusedId);
	const showOrbits = useSim((s) => s.showOrbits);
	const moons = (0, import_react.useMemo)(() => childrenOf(body.id).filter((child) => child.kind === "moon"), [body.id]);
	const orbitPts = (0, import_react.useMemo)(() => body.orbit > 0 ? makeOrbitPoints(body.orbit, body.eccentricity) : null, [body]);
	const inc = body.inclination * Math.PI / 180;
	const lan = body.lan * Math.PI / 180;
	useFrame(() => {
		const group = pivotRef.current;
		if (!group || body.orbit <= 0) return;
		const theta = body.phase + simClock.years / body.period * Math.PI * 2;
		const r = keplerRadius(body.orbit, body.eccentricity, theta);
		group.position.set(Math.cos(theta) * r, 0, Math.sin(theta) * r);
	});
	const onClick = (event) => {
		event.stopPropagation();
		focus(body.id);
	};
	const isFocused = focusedId === body.id;
	const inner = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		ref: (el) => {
			registerBody(body.id, el);
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", {
			onClick,
			onPointerOver: () => {
				document.body.style.cursor = "pointer";
			},
			onPointerOut: () => {
				document.body.style.cursor = "";
			},
			children: body.kind === "star" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SunMesh, { body }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlanetMesh, { body })
		}), moons.map((moon) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CelestialBody, { body: moon }, moon.id))]
	});
	if (body.orbit <= 0) return inner;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", {
		rotation: [
			0,
			lan,
			0
		],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
			rotation: [
				inc,
				0,
				0
			],
			children: [showOrbits && orbitPts ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
				points: orbitPts,
				color: body.color,
				lineWidth: isFocused ? 1.7 : body.kind === "moon" ? .7 : 1.05,
				transparent: true,
				opacity: isFocused ? .7 : body.kind === "moon" ? .16 : .28,
				depthWrite: false,
				raycast: noopRaycast
			}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", {
				ref: pivotRef,
				children: inner
			})]
		})
	});
}
var wanted = new Vector3();
var follow = new Vector3();
var prevFollow = new Vector3();
var offset = new Vector3();
var goal = new Vector3();
var radial = new Vector3();
function daysideCamera(target, radius, focusedId, out) {
	if (focusedId === "system" || target.lengthSq() < .2) {
		out.set(12, 16, 34).setLength(radius);
		return;
	}
	radial.copy(target);
	const distFromSun = radial.length();
	radial.normalize();
	if (distFromSun < radius + 4.2) {
		out.copy(radial).multiplyScalar(radius * .4);
		out.y += radius * .48;
		out.add(target);
		return;
	}
	out.copy(target).addScaledVector(radial, -radius);
	out.y += radius * .3;
}
function CameraRig() {
	const focusedId = useSim((s) => s.focusedId);
	const controlsRef = (0, import_react.useRef)(null);
	const { camera } = useThree();
	const zooming = (0, import_react.useRef)(true);
	const desiredRadius = (0, import_react.useRef)(focusDistance("system"));
	const initialized = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		desiredRadius.current = focusDistance(focusedId);
		zooming.current = true;
	}, [focusedId]);
	useFrame((_, delta) => {
		const d = Math.min(delta, .1);
		const controls = controlsRef.current;
		if (!controls) return;
		const object = focusedId === "system" ? void 0 : getBody(focusedId);
		if (object) object.getWorldPosition(wanted);
		else wanted.set(0, 0, 0);
		if (!initialized.current) {
			follow.copy(wanted);
			prevFollow.copy(wanted);
			initialized.current = true;
		}
		const catchUp = zooming.current ? 1 - Math.exp(-3.1 * d) : 1 - Math.exp(-10 * d);
		follow.lerp(wanted, catchUp);
		offset.copy(follow).sub(prevFollow);
		camera.position.add(offset);
		controls.target.copy(follow);
		prevFollow.copy(follow);
		if (zooming.current) {
			daysideCamera(follow, desiredRadius.current, focusedId, goal);
			camera.position.lerp(goal, 1 - Math.exp(-2.5 * d));
			if (camera.position.distanceTo(goal) < .14) zooming.current = false;
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrbitControls, {
		ref: controlsRef,
		makeDefault: true,
		enableDamping: true,
		dampingFactor: .08,
		enablePan: false,
		minDistance: .6,
		maxDistance: 90,
		minPolarAngle: .12,
		maxPolarAngle: Math.PI * .9
	});
}
var screenLabels = [];
var world = new Vector3();
var camPos = new Vector3();
function LabelProjector() {
	useFrame(({ camera }) => {
		const { showLabels, focusedId } = useSim.getState();
		camera.getWorldPosition(camPos);
		for (let i = 0; i < BODIES.length; i++) {
			const body = BODIES[i];
			let slot = screenLabels[i];
			if (!slot) {
				slot = {
					id: body.id,
					name: body.name,
					x: .5,
					y: .5,
					visible: false
				};
				screenLabels[i] = slot;
			}
			const object = getBody(body.id);
			if (!showLabels || !object) {
				slot.visible = false;
				continue;
			}
			object.getWorldPosition(world);
			const dist = camPos.distanceTo(world);
			world.project(camera);
			const isMoon = body.kind === "moon";
			const related = body.parentId === focusedId || body.id === focusedId;
			const inRange = isMoon ? related && dist < 14 && dist > body.radius * 3 : dist > body.radius * 3.8 && dist < 68;
			const inFront = world.z > -1 && world.z < 1;
			const x = world.x * .5 + .5;
			const y = -world.y * .5 + .5 - Math.min(.045, .012 + body.radius / Math.max(dist, .2) * .35);
			slot.x = x;
			slot.y = y;
			slot.visible = Boolean(inRange && inFront && x > .03 && x < .97 && y > .06 && y < .78);
		}
	});
	return null;
}
function WorldLabels() {
	const show = useSim((s) => s.showLabels);
	const [, setTick] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		if (!show) return;
		const id = window.setInterval(() => setTick((n) => n + 1), 80);
		return () => window.clearInterval(id);
	}, [show]);
	if (!show) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "pointer-events-none absolute inset-0 z-[5]",
		children: screenLabels.map((label) => label.visible ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "absolute -translate-x-1/2 -translate-y-full rounded-md bg-background/55 px-1.5 py-0.5 font-sans text-[10px] tracking-[0.16em] text-foreground/90 uppercase",
			style: {
				left: `${label.x * 100}%`,
				top: `${label.y * 100}%`
			},
			children: label.name
		}, label.id) : null)
	});
}
var dummy = new Object3D();
function Starfield({ count }) {
	const geometry = (0, import_react.useMemo)(() => {
		const positions = new Float32Array(count * 3);
		const colors = new Float32Array(count * 3);
		for (let i = 0; i < count; i++) {
			const r = 50 + Math.random() * 130;
			const theta = Math.random() * Math.PI * 2;
			const phi = Math.acos(2 * Math.random() - 1);
			positions[i * 3] = r * Math.sin(phi) * Math.cos(theta);
			positions[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
			positions[i * 3 + 2] = r * Math.cos(phi);
			const tint = .82 + Math.random() * .18;
			colors[i * 3] = tint;
			colors[i * 3 + 1] = tint * (.95 + Math.random() * .05);
			colors[i * 3 + 2] = tint;
		}
		const geo = new BufferGeometry();
		geo.setAttribute("position", new BufferAttribute(positions, 3));
		geo.setAttribute("color", new BufferAttribute(colors, 3));
		return geo;
	}, [count]);
	useEffectDispose(geometry);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("points", {
		geometry,
		frustumCulled: false,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pointsMaterial", {
			size: .42,
			vertexColors: true,
			sizeAttenuation: true,
			transparent: true,
			opacity: .9,
			depthWrite: false
		})
	});
}
function useEffectDispose(geometry) {
	(0, import_react.useLayoutEffect)(() => () => geometry.dispose(), [geometry]);
}
function AsteroidBelt() {
	const meshRef = (0, import_react.useRef)(null);
	const count = 420;
	const seeds = (0, import_react.useMemo)(() => {
		const arr = new Float32Array(count * 4);
		for (let i = 0; i < count; i++) {
			const t = Math.random() * Math.PI * 2;
			const r = 12.2 + Math.random() * 2.4;
			arr[i * 4] = t;
			arr[i * 4 + 1] = r;
			arr[i * 4 + 2] = (Math.random() - .5) * .35;
			arr[i * 4 + 3] = .012 + Math.random() * .03;
		}
		return arr;
	}, []);
	(0, import_react.useLayoutEffect)(() => {
		const mesh = meshRef.current;
		if (!mesh) return;
		for (let i = 0; i < count; i++) {
			const t = seeds[i * 4];
			const r = seeds[i * 4 + 1];
			const y = seeds[i * 4 + 2];
			const s = seeds[i * 4 + 3];
			dummy.position.set(Math.cos(t) * r, y, Math.sin(t) * r);
			dummy.rotation.set(t, t * .4, t * 1.3);
			dummy.scale.setScalar(s);
			dummy.updateMatrix();
			mesh.setMatrixAt(i, dummy.matrix);
		}
		mesh.instanceMatrix.needsUpdate = true;
	}, [count, seeds]);
	const groupRef = (0, import_react.useRef)(null);
	useFrame(() => {
		if (groupRef.current) groupRef.current.rotation.y = simClock.years * .12;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", {
		ref: groupRef,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("instancedMesh", {
			ref: meshRef,
			args: [
				void 0,
				void 0,
				count
			],
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("icosahedronGeometry", { args: [1, 0] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
				color: "#6a645e",
				roughness: .95,
				metalness: .08
			})]
		})
	});
}
function Scene() {
	const roots = (0, import_react.useMemo)(() => BODIES.filter((b) => b.parentId === null || b.parentId === "sun"), []);
	const starCount = typeof window !== "undefined" && window.innerWidth < 640 ? 2800 : 5600;
	useFrame((_, delta) => {
		const d = Math.min(delta, .1);
		const { paused, timeScale } = useSim.getState();
		if (!paused) simClock.years += d * timeScale / 22;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("color", {
			attach: "background",
			args: ["#07080c"]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ambientLight", {
			intensity: .26,
			color: "#9aa6bc"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("hemisphereLight", { args: [
			"#c5d0e0",
			"#0c0806",
			.22
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Starfield, { count: starCount }),
		roots.map((body) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CelestialBody, { body }, body.id)),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AsteroidBelt, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CameraRig, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LabelProjector, {})
	] });
}
function HeliosApp() {
	(0, import_react.useEffect)(() => {
		window.__helios = {
			focus: (id) => useSim.getState().focus(id),
			pause: () => useSim.getState().setPaused(true),
			play: () => useSim.getState().setPaused(false),
			reset: () => useSim.getState().resetView(),
			getState: () => useSim.getState()
		};
		return () => {
			delete window.__helios;
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "relative h-dvh w-full touch-none overflow-hidden bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Canvas, {
				className: "h-full w-full bg-background",
				camera: {
					position: [
						11,
						15,
						34
					],
					fov: 42,
					near: .12,
					far: 400
				},
				dpr: [1, 1.75],
				gl: {
					antialias: true,
					powerPreference: "high-performance",
					toneMapping: 4,
					toneMappingExposure: 1.05
				},
				onCreated: ({ gl }) => {
					gl.setClearColor("#07080c", 1);
				},
				resize: { scroll: false },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scene, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorldLabels, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Overlay, {})
		]
	});
}
//#endregion
export { HeliosApp as default };
